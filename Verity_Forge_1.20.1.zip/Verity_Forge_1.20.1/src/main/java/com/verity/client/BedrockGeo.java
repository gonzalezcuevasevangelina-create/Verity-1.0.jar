package com.verity.client;

import com.google.gson.JsonArray;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import com.mojang.blaze3d.vertex.PoseStack;
import com.mojang.blaze3d.vertex.VertexConsumer;
import net.minecraft.client.Minecraft;
import net.minecraft.resources.ResourceLocation;
import org.joml.Matrix3f;
import org.joml.Matrix4f;
import org.joml.Quaternionf;

import java.io.InputStreamReader;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

/**
 * Cargador/renderizador de geometrías de Bedrock (.geo.json) con poly_mesh y cubos.
 * Las posiciones están en unidades de modelo (1/16 de bloque), eje Y hacia arriba.
 * El que llama aplica la escala (-1/16, 1/16, 1/16) para pasarlo al mundo de Java.
 */
public final class BedrockGeo {
    public static final class Quad {
        final float[] x = new float[4], y = new float[4], z = new float[4];
        final float[] nx = new float[4], ny = new float[4], nz = new float[4];
        final float[] u = new float[4], v = new float[4];
    }

    public static final class Bone {
        public String name;
        public Bone parent;
        public float[] pivot = {0, 0, 0};
        public float[] rot = {0, 0, 0};
        public final List<Bone> children = new ArrayList<>();
        public final List<Quad> quads = new ArrayList<>();
    }

    /** Pose animada de un hueso (rotación en grados, posición en unidades de modelo). */
    public static final class Pose {
        public float rx, ry, rz, px, py, pz, sx = 1, sy = 1, sz = 1;
    }

    private static final Map<ResourceLocation, BedrockGeo> CACHE = new HashMap<>();

    public final Map<String, Bone> bones = new LinkedHashMap<>();
    private final List<Bone> roots = new ArrayList<>();

    public static BedrockGeo get(ResourceLocation rl) {
        return CACHE.computeIfAbsent(rl, BedrockGeo::load);
    }

    private static BedrockGeo load(ResourceLocation rl) {
        try (var in = Minecraft.getInstance().getResourceManager().getResourceOrThrow(rl).open();
             var rd = new InputStreamReader(in, java.nio.charset.StandardCharsets.UTF_8)) {
            JsonObject root = JsonParser.parseReader(rd).getAsJsonObject();
            JsonObject geo = root.getAsJsonArray("minecraft:geometry").get(0).getAsJsonObject();
            JsonObject desc = geo.getAsJsonObject("description");
            float tw = desc.get("texture_width").getAsFloat(), th = desc.get("texture_height").getAsFloat();
            BedrockGeo g = new BedrockGeo();
            JsonArray arr = geo.getAsJsonArray("bones");
            Map<String, String> parents = new HashMap<>();
            for (JsonElement el : arr) {
                JsonObject b = el.getAsJsonObject();
                Bone bone = new Bone();
                bone.name = b.get("name").getAsString();
                if (b.has("pivot")) bone.pivot = floats(b.getAsJsonArray("pivot"));
                if (b.has("rotation")) bone.rot = floats(b.getAsJsonArray("rotation"));
                if (b.has("parent")) parents.put(bone.name, b.get("parent").getAsString());
                if (b.has("poly_mesh")) readPolyMesh(b.getAsJsonObject("poly_mesh"), bone);
                if (b.has("cubes")) for (JsonElement c : b.getAsJsonArray("cubes")) readCube(c.getAsJsonObject(), bone, tw, th);
                g.bones.put(bone.name, bone);
            }
            for (Bone b : g.bones.values()) {
                String p = parents.get(b.name);
                if (p != null && g.bones.containsKey(p)) { b.parent = g.bones.get(p); b.parent.children.add(b); }
                else g.roots.add(b);
            }
            return g;
        } catch (Exception ex) {
            throw new RuntimeException("No se pudo cargar la geometría " + rl, ex);
        }
    }

    private static float[] floats(JsonArray a) {
        float[] r = new float[a.size()];
        for (int i = 0; i < r.length; i++) r[i] = a.get(i).getAsFloat();
        return r;
    }

    private static void readPolyMesh(JsonObject pm, Bone bone) {
        JsonArray pos = pm.getAsJsonArray("positions"), nor = pm.getAsJsonArray("normals"), uvs = pm.getAsJsonArray("uvs");
        boolean normalized = !pm.has("normalized_uvs") || pm.get("normalized_uvs").getAsBoolean();
        for (JsonElement pe : pm.getAsJsonArray("polys")) {
            JsonArray poly = pe.getAsJsonArray();
            int n = poly.size();
            if (n < 3) continue;
            Quad q = new Quad();
            for (int i = 0; i < 4; i++) {
                JsonArray vtx = poly.get(Math.min(i, n - 1)).getAsJsonArray(); // un triángulo repite su último vértice
                JsonArray p = pos.get(vtx.get(0).getAsInt()).getAsJsonArray();
                JsonArray nn = nor.get(vtx.get(1).getAsInt()).getAsJsonArray();
                JsonArray uv = uvs.get(vtx.get(2).getAsInt()).getAsJsonArray();
                q.x[i] = p.get(0).getAsFloat(); q.y[i] = p.get(1).getAsFloat(); q.z[i] = p.get(2).getAsFloat();
                q.nx[i] = nn.get(0).getAsFloat(); q.ny[i] = nn.get(1).getAsFloat(); q.nz[i] = nn.get(2).getAsFloat();
                q.u[i] = uv.get(0).getAsFloat();
                q.v[i] = normalized ? 1.0f - uv.get(1).getAsFloat() : uv.get(1).getAsFloat();
            }
            bone.quads.add(q);
        }
    }

    private static void readCube(JsonObject c, Bone bone, float tw, float th) {
        float[] o = floats(c.getAsJsonArray("origin")), s = floats(c.getAsJsonArray("size"));
        float x0 = o[0], y0 = o[1], z0 = o[2], x1 = x0 + s[0], y1 = y0 + s[1], z1 = z0 + s[2];
        JsonObject uv = c.getAsJsonObject("uv");
        // esquinas: arriba-izq, arriba-der, abajo-der, abajo-izq
        String[] names = {"north", "south", "east", "west", "up", "down"};
        float[][][] corners = {
            {{x1, y1, z0}, {x0, y1, z0}, {x0, y0, z0}, {x1, y0, z0}},
            {{x0, y1, z1}, {x1, y1, z1}, {x1, y0, z1}, {x0, y0, z1}},
            {{x1, y1, z1}, {x1, y1, z0}, {x1, y0, z0}, {x1, y0, z1}},
            {{x0, y1, z0}, {x0, y1, z1}, {x0, y0, z1}, {x0, y0, z0}},
            {{x0, y1, z0}, {x1, y1, z0}, {x1, y1, z1}, {x0, y1, z1}},
            {{x0, y0, z1}, {x1, y0, z1}, {x1, y0, z0}, {x0, y0, z0}},
        };
        float[][] normals = {{0, 0, -1}, {0, 0, 1}, {1, 0, 0}, {-1, 0, 0}, {0, 1, 0}, {0, -1, 0}};
        for (int f = 0; f < 6; f++) {
            if (!uv.has(names[f])) continue;
            JsonObject fu = uv.getAsJsonObject(names[f]);
            float[] p = floats(fu.getAsJsonArray("uv")), sz = floats(fu.getAsJsonArray("uv_size"));
            float[][] t = {{p[0], p[1]}, {p[0] + sz[0], p[1]}, {p[0] + sz[0], p[1] + sz[1]}, {p[0], p[1] + sz[1]}};
            Quad q = new Quad();
            for (int i = 0; i < 4; i++) {
                q.x[i] = corners[f][i][0]; q.y[i] = corners[f][i][1]; q.z[i] = corners[f][i][2];
                q.nx[i] = normals[f][0]; q.ny[i] = normals[f][1]; q.nz[i] = normals[f][2];
                q.u[i] = t[i][0] / tw; q.v[i] = t[i][1] / th;
            }
            bone.quads.add(q);
        }
    }

    // ---------------------------------------------------------------- render

    public void render(PoseStack ps, VertexConsumer vc, int light, int overlay, Map<String, Pose> poses) {
        for (Bone b : roots) renderBone(b, ps, vc, light, overlay, poses);
    }

    private void renderBone(Bone b, PoseStack ps, VertexConsumer vc, int light, int overlay, Map<String, Pose> poses) {
        Pose p = poses == null ? null : poses.get(b.name);
        ps.pushPose();
        if (p != null) ps.translate(p.px, p.py, p.pz);
        float rx = b.rot[0] + (p == null ? 0 : p.rx), ry = b.rot[1] + (p == null ? 0 : p.ry), rz = b.rot[2] + (p == null ? 0 : p.rz);
        ps.translate(b.pivot[0], b.pivot[1], b.pivot[2]);
        if (rx != 0 || ry != 0 || rz != 0) {
            // convención de Bedrock -> mundo espejado de Java: se invierten los ángulos
            ps.mulPose(new Quaternionf().rotationZYX((float) Math.toRadians(-rz), (float) Math.toRadians(-ry), (float) Math.toRadians(-rx)));
        }
        if (p != null && (p.sx != 1 || p.sy != 1 || p.sz != 1)) ps.scale(p.sx, p.sy, p.sz);
        ps.translate(-b.pivot[0], -b.pivot[1], -b.pivot[2]);

        Matrix4f m = ps.last().pose();
        Matrix3f n = ps.last().normal();
        for (Quad q : b.quads) {
            for (int i = 0; i < 4; i++) {
                vc.vertex(m, q.x[i], q.y[i], q.z[i]).color(255, 255, 255, 255).uv(q.u[i], q.v[i])
                        .overlayCoords(overlay).uv2(light).normal(n, q.nx[i], q.ny[i], q.nz[i]).endVertex();
            }
        }
        for (Bone c : b.children) renderBone(c, ps, vc, light, overlay, poses);
        ps.popPose();
    }

    // ---------------------------------------------------------------- utilidades de animación

    /** Interpolación Catmull-Rom sobre fotogramas clave (t crece). Fuera de rango: mantiene el extremo. */
    public static float catmull(float[] t, float[] v, float x) {
        int n = t.length;
        if (x <= t[0]) return v[0];
        if (x >= t[n - 1]) return v[n - 1];
        int i = 0;
        while (i < n - 2 && x > t[i + 1]) i++;
        float p0 = v[Math.max(0, i - 1)], p1 = v[i], p2 = v[i + 1], p3 = v[Math.min(n - 1, i + 2)];
        float s = (x - t[i]) / (t[i + 1] - t[i]);
        float s2 = s * s, s3 = s2 * s;
        return 0.5f * ((2 * p1) + (-p0 + p2) * s + (2 * p0 - 5 * p1 + 4 * p2 - p3) * s2 + (-p0 + 3 * p1 - 3 * p2 + p3) * s3);
    }

    public static Pose pose(Map<String, Pose> m, String name) {
        return m.computeIfAbsent(name, k -> new Pose());
    }
}
