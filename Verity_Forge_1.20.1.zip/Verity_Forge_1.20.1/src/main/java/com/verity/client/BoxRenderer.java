package com.verity.client;

import com.mojang.blaze3d.vertex.PoseStack;
import com.mojang.math.Axis;
import com.verity.VerityMod;
import com.verity.entity.BoxEntity;
import net.minecraft.client.renderer.MultiBufferSource;
import net.minecraft.client.renderer.RenderType;
import net.minecraft.client.renderer.entity.EntityRenderer;
import net.minecraft.client.renderer.entity.EntityRendererProvider;
import net.minecraft.client.renderer.texture.OverlayTexture;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.util.Mth;

import java.util.HashMap;
import java.util.Map;

/** La caja: flota con latidos y, al abrirla, sube, abre las tapas y se encoge (animación del mod de Java). */
public class BoxRenderer extends EntityRenderer<BoxEntity> {
    private static final ResourceLocation GEO = new ResourceLocation(VerityMod.MODID, "geo/box.geo.json");
    private static final ResourceLocation TEX = new ResourceLocation(VerityMod.MODID, "textures/entity/box.png");

    public BoxRenderer(EntityRendererProvider.Context ctx) {
        super(ctx);
        shadowRadius = 0.4f;
    }

    @Override
    public ResourceLocation getTextureLocation(BoxEntity e) { return TEX; }

    private static float pulse(float t, float c) {
        return 1.0f + 0.1f * Math.max(0.0f, 1.0f - Math.abs(t - c) / 0.0833f);
    }

    @Override
    public void render(BoxEntity e, float yaw, float pt, PoseStack ps, MultiBufferSource buf, int light) {
        Map<String, BedrockGeo.Pose> poses = new HashMap<>();
        BedrockGeo.Pose anchor = BedrockGeo.pose(poses, "anchor");
        BedrockGeo.Pose left = BedrockGeo.pose(poses, "left");
        BedrockGeo.Pose right = BedrockGeo.pose(poses, "right");

        int open = e.getOpenTicks();
        if (open >= 0) {
            float t = (open + pt) / 20.0f;
            float x = Mth.clamp(t / 0.75f, 0, 1);
            anchor.py = 16.0f * (float) Math.sqrt(1 - (x - 1) * (x - 1)); // easeOutCirc
            float l = Mth.clamp((t - 0.5f) / 0.5f, 0, 1);
            float ang = 130.0f * (float) (-(Math.cos(Math.PI * l) - 1) / 2); // easeInOutSine
            left.rx = -ang;
            right.rx = ang;
            float s = Mth.clamp((t - 1.25f) / 0.75f, 0, 1);
            float sc = 1.0f - 0.9f * (float) Math.pow(2, 10 * s - 10) * (s > 0 ? 1 : 0); // easeInExpo
            anchor.sx = anchor.sy = anchor.sz = sc;
        } else {
            float t = ((e.tickCount + pt) / 20.0f) % 2.0f;
            anchor.py = 1.0f - (float) Math.cos(Math.PI * t);
            float s = Math.max(pulse(t, 0.5f), Math.max(pulse(t, 1.2917f), pulse(t, 1.5417f)));
            anchor.sx = anchor.sy = anchor.sz = s;
        }

        ps.pushPose();
        ps.mulPose(Axis.YP.rotationDegrees(180.0f - e.getYRot()));
        ps.scale(-1.0f / 16.0f, 1.0f / 16.0f, 1.0f / 16.0f);
        BedrockGeo.get(GEO).render(ps, buf.getBuffer(RenderType.entityCutoutNoCull(TEX)), light, OverlayTexture.NO_OVERLAY, poses);
        ps.popPose();
        super.render(e, yaw, pt, ps, buf, light);
    }
}
