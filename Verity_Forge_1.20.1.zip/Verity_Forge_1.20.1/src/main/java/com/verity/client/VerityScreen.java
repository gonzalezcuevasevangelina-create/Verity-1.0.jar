package com.verity.client;

import com.verity.network.Network;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.components.Button;
import net.minecraft.client.gui.components.EditBox;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.network.chat.Component;

/** Menú "Verity": caja de texto + frases rápidas. Lo que dices llega al servidor; ella responde en el chat. */
public class VerityScreen extends Screen {
    private static final String[][] PRESETS = {
        {"Saludar", "hola"}, {"¿Cómo estás?", "como estas"}, {"¿Quién eres?", "quien eres"},
        {"Dar las gracias", "gracias"}, {"Te quiero", "te quiero"}, {"Contar un chiste", "chiste"},
        {"¿Qué puedes hacer?", "ayuda"}, {"Mencionar al Smiler", "smiler"}, {"Que camine", "camina"},
        {"Que se quede quieta", "quieta"}, {"Despedirte", "adios"},
    };

    private EditBox box;

    public VerityScreen() {
        super(Component.literal("Verity"));
    }

    @Override
    protected void init() {
        int cx = width / 2;
        int top = height / 2 - 80;
        box = new EditBox(font, cx - 100, top + 18, 200, 20, Component.literal("Mensaje"));
        box.setMaxLength(120);
        addRenderableWidget(box);
        setInitialFocus(box);
        addRenderableWidget(Button.builder(Component.literal("Enviar"), b -> send(box.getValue()))
                .bounds(cx - 100, top + 42, 200, 20).build());
        for (int i = 0; i < PRESETS.length; i++) {
            final String msg = PRESETS[i][1];
            int col = i % 2, row = i / 2;
            addRenderableWidget(Button.builder(Component.literal(PRESETS[i][0]), b -> send(msg))
                    .bounds(cx - 100 + col * 102, top + 70 + row * 22, 98, 20).build());
        }
    }

    private void send(String text) {
        if (text == null || text.isBlank()) return;
        Network.CHANNEL.sendToServer(new Network.TalkPacket(text));
        onClose();
    }

    @Override
    public boolean keyPressed(int key, int scan, int mods) {
        if ((key == 257 || key == 335) && box.isFocused()) { // Enter
            send(box.getValue());
            return true;
        }
        return super.keyPressed(key, scan, mods);
    }

    @Override
    public void render(GuiGraphics g, int mx, int my, float pt) {
        renderBackground(g);
        g.drawCenteredString(font, "§eVerity", width / 2, height / 2 - 80, 0xFFFFFF);
        super.render(g, mx, my, pt);
    }

    @Override
    public boolean isPauseScreen() { return false; }
}
