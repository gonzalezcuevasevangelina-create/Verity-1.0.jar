package com.verity.client;

import com.mojang.blaze3d.vertex.PoseStack;
import com.mojang.math.Axis;
import com.verity.VerityMod;
import com.verity.entity.VerityEntity;
import com.verity.story.Faces;
import net.minecraft.client.renderer.MultiBufferSource;
import net.minecraft.client.renderer.RenderType;
import net.minecraft.client.renderer.entity.EntityRenderer;
import net.minecraft.client.renderer.entity.EntityRendererProvider;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.util.Mth;

import java.util.HashMap;
import java.util.Map;

public class VerityRenderer extends EntityRenderer<VerityEntity> {
    static final ResourceLocation GEO = new ResourceLocation(VerityMod.MODID, "geo/verity.geo.json");
    private static final ResourceLocation[] FACES = new ResourceLocation[Faces.NAMES.length];
    static {
        for (int i = 0; i < FACES.length; i++) FACES[i] = new ResourceLocation(VerityMod.MODID, "textures/entity/verity_" + Faces.NAMES[i] + ".png");
    }

    // animación "ball_fall" (pntmc): tiempos en segundos
    private static final float[] RX_T = {0, .8333f, 1.1667f, 1.5417f, 1.9583f, 2.375f, 2.8333f, 3.125f, 3.375f};
    private static final float[] RX_V = {0, 45, 25, -15, -2.5f, 20, 0, -5, 0};
    private static final float[] Y_T = {0, .5f, .9583f, 1.4167f, 1.875f, 2.4167f, 2.875f, 3.2083f, 3.5833f, 3.75f, 3.9167f, 4.0417f};
    private static final float[] Y_V = {75, 75, 49.92f, -1, 36, -1, 16, -1, 2, -.5f, 1, 0};
    private static final float[] S_T = {0, .5f, .9583f, 1.4583f, 1.875f, 2.4167f, 2.875f, 3.2083f, 3.5833f, 3.75f, 3.9167f, 4.0417f};
    private static final float[] SXZ = {1, 1, 1, 1.2f, 1, 1.1f, 1, 1.1f, 1, 1, 1, 1};
    private static final float[] SY = {1, 1, 1, .75f, 1, .85f, 1, .95f, 1, .9f, 1, 1};

    public VerityRenderer(EntityRendererProvider.Context ctx) {
        super(ctx);
        shadowRadius = 0.25f;
    }

    @Override
    public ResourceLocation getTextureLocation(VerityEntity e) {
        return FACES[Mth.clamp(e.getFace(), 0, FACES.length - 1)];
    }

    @Override
    public void render(VerityEntity e, float yaw, float pt, PoseStack ps, MultiBufferSource buf, int light) {
        BedrockGeo geo = BedrockGeo.get(GEO);
        Map<String, BedrockGeo.Pose> poses = new HashMap<>();
        BedrockGeo.Pose bone = BedrockGeo.pose(poses, "bone");

        float headYaw = Mth.rotLerp(pt, e.yHeadRotO, e.yHeadRot);
        if (e.isFalling()) {
            float t = (e.fallTicks + pt) / 20.0f;
            bone.rx = BedrockGeo.catmull(RX_T, RX_V, t);
            bone.py = BedrockGeo.catmull(Y_T, Y_V, t);
            bone.sx = bone.sz = BedrockGeo.catmull(S_T, SXZ, t);
            bone.sy = BedrockGeo.catmull(S_T, SY, t);
        } else {
            double speed = Math.hypot(e.getDeltaMovement().x, e.getDeltaMovement().z) * 20.0;
            if (e.isFollowing() && speed > 0.05) { // rueda cuando camina
                bone.rx = Mth.lerp(pt, e.walkDistO, e.walkDist) * 229.0f % 360.0f;
            } else {
                bone.rx = Mth.clamp(Mth.lerp(pt, e.xRotO, e.getXRot()), -30, 30);
            }
        }

        ps.pushPose();
        ps.mulPose(Axis.YP.rotationDegrees(180.0f - headYaw));
        ps.scale(-1.0f / 16.0f, 1.0f / 16.0f, 1.0f / 16.0f);
        geo.render(ps, buf.getBuffer(RenderType.entityCutoutNoCull(getTextureLocation(e))), light,
                net.minecraft.client.renderer.texture.OverlayTexture.NO_OVERLAY, poses);
        ps.popPose();
        super.render(e, yaw, pt, ps, buf, light);
    }
}
