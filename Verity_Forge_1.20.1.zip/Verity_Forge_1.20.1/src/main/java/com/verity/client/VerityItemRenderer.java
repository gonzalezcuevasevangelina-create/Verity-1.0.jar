package com.verity.client;

import com.mojang.blaze3d.vertex.PoseStack;
import com.mojang.math.Axis;
import com.verity.VerityMod;
import net.minecraft.client.Minecraft;
import net.minecraft.client.renderer.BlockEntityWithoutLevelRenderer;
import net.minecraft.client.renderer.MultiBufferSource;
import net.minecraft.client.renderer.RenderType;
import net.minecraft.client.renderer.texture.OverlayTexture;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.world.item.ItemDisplayContext;
import net.minecraft.world.item.ItemStack;

/** Dibuja el objeto de Verity en 3D (mano, inventario, suelo). La posición sale del "display" del modelo. */
public class VerityItemRenderer extends BlockEntityWithoutLevelRenderer {
    private static final ResourceLocation TEX = new ResourceLocation(VerityMod.MODID, "textures/entity/verity_smile1.png");

    public VerityItemRenderer() {
        super(Minecraft.getInstance().getBlockEntityRenderDispatcher(), Minecraft.getInstance().getEntityModels());
    }

    @Override
    public void renderByItem(ItemStack stack, ItemDisplayContext ctx, PoseStack ps, MultiBufferSource buf, int light, int overlay) {
        ps.pushPose();
        ps.translate(0.5, 0.5, 0.5);
        ps.mulPose(Axis.YP.rotationDegrees(180.0f));
        ps.scale(-1.0f / 16.0f, 1.0f / 16.0f, 1.0f / 16.0f);
        ps.translate(0, -4, 0); // centro de la bola (pivote 0,4,0)
        BedrockGeo.get(VerityRenderer.GEO).render(ps, buf.getBuffer(RenderType.entityCutoutNoCull(TEX)), light, OverlayTexture.NO_OVERLAY, null);
        ps.popPose();
    }
}
