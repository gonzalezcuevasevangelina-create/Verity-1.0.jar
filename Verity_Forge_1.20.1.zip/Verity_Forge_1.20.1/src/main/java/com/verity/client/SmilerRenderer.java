package com.verity.client;

import com.mojang.blaze3d.vertex.PoseStack;
import com.mojang.math.Axis;
import com.verity.VerityMod;
import com.verity.entity.SmilerEntity;
import net.minecraft.client.renderer.MultiBufferSource;
import net.minecraft.client.renderer.RenderType;
import net.minecraft.client.renderer.entity.EntityRenderer;
import net.minecraft.client.renderer.entity.EntityRendererProvider;
import net.minecraft.client.renderer.texture.OverlayTexture;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.util.Mth;

import java.util.HashMap;
import java.util.Map;

/** El Smiler: modelo de ~3.2 bloques escalado x2.5 (8 bloques). Poses de rodillas/agachado aproximadas. */
public class SmilerRenderer extends EntityRenderer<SmilerEntity> {
    private static final ResourceLocation GEO = new ResourceLocation(VerityMod.MODID, "geo/smiler.geo.json");
    private static final ResourceLocation TEX = new ResourceLocation(VerityMod.MODID, "textures/entity/smiler.png");

    public SmilerRenderer(EntityRendererProvider.Context ctx) {
        super(ctx);
        shadowRadius = 1.2f;
    }

    @Override
    public ResourceLocation getTextureLocation(SmilerEntity e) { return TEX; }

    @Override
    public void render(SmilerEntity e, float yaw, float pt, PoseStack ps, MultiBufferSource buf, int light) {
        Map<String, BedrockGeo.Pose> poses = new HashMap<>();
        float k = Mth.lerp(pt, e.wKneelO, e.wKneel);
        float c = Mth.lerp(pt, e.wCrouchO, e.wCrouch);
        float scale = Mth.lerp(pt, e.visScaleO, e.visScale);
        float w = Math.max(k, c);

        // andar: balanceo de piernas y brazos
        float speed = (float) Math.min(1.0, Math.hypot(e.getDeltaMovement().x, e.getDeltaMovement().z) * 6.0);
        float swing = Mth.sin(Mth.lerp(pt, e.walkDistO, e.walkDist) * 0.6f) * 40.0f * speed * (1 - w);
        BedrockGeo.pose(poses, "LeftLeg").rx = swing;
        BedrockGeo.pose(poses, "RightLeg").rx = -swing;
        BedrockGeo.pose(poses, "LeftArm").rx = -swing * 0.8f;
        BedrockGeo.pose(poses, "RightArm").rx = swing * 0.8f;

        // de rodillas / agachado: baja el cuerpo, dobla piernas, inclina el torso
        if (w > 0.001f) {
            BedrockGeo.pose(poses, "Body").py = -22.0f * k - 14.0f * c;
            BedrockGeo.pose(poses, "LeftLeg").rx += -75.0f * k - 50.0f * c;
            BedrockGeo.pose(poses, "RightLeg").rx += -75.0f * k - 50.0f * c;
            BedrockGeo.pose(poses, "LeftLower").rx = 110.0f * k + 70.0f * c;
            BedrockGeo.pose(poses, "RightLower").rx = 110.0f * k + 70.0f * c;
            BedrockGeo.pose(poses, "torso").rx = 12.0f * c;
        }
        // la cabeza mira hacia donde mira la entidad
        float bodyYaw = Mth.rotLerp(pt, e.yBodyRotO, e.yBodyRot);
        float headYaw = Mth.rotLerp(pt, e.yHeadRotO, e.yHeadRot);
        BedrockGeo.pose(poses, "neck").ry = Mth.clamp(Mth.wrapDegrees(headYaw - bodyYaw), -60, 60);
        BedrockGeo.pose(poses, "neck").rx = Mth.clamp(Mth.lerp(pt, e.xRotO, e.getXRot()), -30, 30);

        ps.pushPose();
        ps.mulPose(Axis.YP.rotationDegrees(180.0f - bodyYaw));
        float s = scale / 16.0f;
        ps.scale(-s, s, s);
        BedrockGeo.get(GEO).render(ps, buf.getBuffer(RenderType.entityCutoutNoCull(TEX)), light, OverlayTexture.NO_OVERLAY, poses);
        ps.popPose();
        super.render(e, yaw, pt, ps, buf, light);
    }
}
