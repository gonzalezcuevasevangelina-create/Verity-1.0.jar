package com.verity.client;

import com.verity.VerityMod;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.client.event.EntityRenderersEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;

@Mod.EventBusSubscriber(modid = VerityMod.MODID, bus = Mod.EventBusSubscriber.Bus.MOD, value = Dist.CLIENT)
public final class ClientSetup {
    private ClientSetup() {}

    @SubscribeEvent
    public static void renderers(EntityRenderersEvent.RegisterRenderers e) {
        e.registerEntityRenderer(VerityMod.VERITY.get(), VerityRenderer::new);
        e.registerEntityRenderer(VerityMod.SMILER.get(), SmilerRenderer::new);
        e.registerEntityRenderer(VerityMod.BOX.get(), BoxRenderer::new);
    }
}
