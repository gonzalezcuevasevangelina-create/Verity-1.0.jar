package com.verity.client;

import net.minecraft.client.Minecraft;

/** Puente seguro para abrir pantallas solo en el cliente. */
public final class ClientHooks {
    private ClientHooks() {}

    public static void openVerityScreen() {
        Minecraft.getInstance().setScreen(new VerityScreen());
    }
}
