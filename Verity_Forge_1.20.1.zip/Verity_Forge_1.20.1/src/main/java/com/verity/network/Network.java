package com.verity.network;

import com.verity.VerityMod;
import net.minecraft.network.FriendlyByteBuf;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.server.level.ServerPlayer;
import net.minecraftforge.network.NetworkEvent;
import net.minecraftforge.network.NetworkRegistry;
import net.minecraftforge.network.simple.SimpleChannel;
import com.verity.story.StoryManager;

import java.util.function.Supplier;

public final class Network {
    private static final String PROTOCOL = "1";
    public static final SimpleChannel CHANNEL = NetworkRegistry.newSimpleChannel(
            new ResourceLocation(VerityMod.MODID, "main"), () -> PROTOCOL, PROTOCOL::equals, PROTOCOL::equals);

    private Network() {}

    public static void init() {
        CHANNEL.registerMessage(0, TalkPacket.class, TalkPacket::encode, TalkPacket::decode, TalkPacket::handle);
    }

    /** Cliente -> servidor: lo que le dices a Verity desde el menú. */
    public static class TalkPacket {
        public final String text;

        public TalkPacket(String text) { this.text = text; }

        public static void encode(TalkPacket p, FriendlyByteBuf buf) { buf.writeUtf(p.text, 256); }

        public static TalkPacket decode(FriendlyByteBuf buf) { return new TalkPacket(buf.readUtf(256)); }

        public static void handle(TalkPacket p, Supplier<NetworkEvent.Context> sup) {
            NetworkEvent.Context ctx = sup.get();
            ctx.enqueueWork(() -> {
                ServerPlayer sender = ctx.getSender();
                if (sender != null) StoryManager.onTalk(sender, p.text);
            });
            ctx.setPacketHandled(true);
        }
    }
}
