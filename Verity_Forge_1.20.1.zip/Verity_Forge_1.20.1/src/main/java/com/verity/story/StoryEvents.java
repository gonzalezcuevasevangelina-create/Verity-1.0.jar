package com.verity.story;

import com.mojang.brigadier.CommandDispatcher;
import com.mojang.brigadier.arguments.IntegerArgumentType;
import com.verity.VerityMod;
import com.verity.entity.VerityEntity;
import net.minecraft.commands.CommandSourceStack;
import net.minecraft.commands.Commands;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.entity.item.ItemEntity;
import net.minecraftforge.event.RegisterCommandsEvent;
import net.minecraftforge.event.TickEvent;
import net.minecraftforge.event.entity.EntityJoinLevelEvent;
import net.minecraftforge.event.entity.living.LivingAttackEvent;
import net.minecraftforge.event.entity.living.LivingDeathEvent;
import net.minecraftforge.event.entity.player.PlayerEvent;
import net.minecraftforge.event.server.ServerStartedEvent;
import net.minecraftforge.event.server.ServerStoppingEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;

/** Eventos de Forge que mueven la historia. */
@Mod.EventBusSubscriber(modid = VerityMod.MODID)
public final class StoryEvents {
    private StoryEvents() {}

    private static int counter = 0;

    @SubscribeEvent
    public static void onStarted(ServerStartedEvent e) {
        StoryManager.setServer(e.getServer());
    }

    @SubscribeEvent
    public static void onStopping(ServerStoppingEvent e) {
        Scheduler.clear();
    }

    @SubscribeEvent
    public static void onTick(TickEvent.ServerTickEvent e) {
        if (e.phase != TickEvent.Phase.END || StoryManager.server() == null) return;
        Scheduler.tick();
        if (++counter >= 20) {
            counter = 0;
            StoryManager.storyTick();
        }
    }

    @SubscribeEvent
    public static void onLogin(PlayerEvent.PlayerLoggedInEvent e) {
        if (e.getEntity() instanceof ServerPlayer sp && StoryManager.server() != null) StoryManager.onLogin(sp);
    }

    /** Si sueltas el objeto de Verity (Q), vuelve a ser Verity. */
    @SubscribeEvent
    public static void onJoin(EntityJoinLevelEvent e) {
        if (e.getLevel().isClientSide() || !(e.getLevel() instanceof ServerLevel sl)) return;
        if (e.getEntity() instanceof ItemEntity ie && ie.getItem().is(VerityMod.VERITY_ITEM.get()) && StoryManager.server() != null) {
            // un tick después, para que la entidad ya esté completamente creada
            Scheduler.later(1, () -> { if (ie.isAlive()) StoryManager.onItemDropped(ie, sl); });
        }
    }

    @SubscribeEvent
    public static void onDeath(LivingDeathEvent e) {
        if (e.getEntity() instanceof VerityEntity v && !v.level().isClientSide && StoryManager.server() != null) StoryManager.onVerityDied(v);
    }

    /** Los jugadores no pueden hacer daño a ninguna entidad (el clic izquierdo en Verity/caja sigue funcionando). */
    @SubscribeEvent
    public static void onAttack(LivingAttackEvent e) {
        if (e.getSource().getEntity() instanceof net.minecraft.world.entity.player.Player) e.setCanceled(true);
    }

    @SubscribeEvent
    public static void onCommands(RegisterCommandsEvent e) {
        CommandDispatcher<CommandSourceStack> d = e.getDispatcher();
        d.register(Commands.literal("verity").requires(s -> s.hasPermission(2))
            .then(Commands.literal("fase").then(Commands.argument("n", IntegerArgumentType.integer(1, 5)).executes(c -> {
                StoryManager.setPhase(IntegerArgumentType.getInteger(c, "n"));
                c.getSource().sendSuccess(() -> Component.literal(StoryManager.estado()), false);
                return 1;
            })))
            .then(Commands.literal("estado").executes(c -> {
                c.getSource().sendSuccess(() -> Component.literal(StoryManager.estado()), false);
                return 1;
            }))
            .then(Commands.literal("reset").executes(c -> {
                StoryManager.reset(c.getSource().getPlayer());
                c.getSource().sendSuccess(() -> Component.literal("Historia reiniciada."), false);
                return 1;
            })));
    }
}
