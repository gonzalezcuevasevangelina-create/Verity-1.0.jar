package com.verity.story;

import com.verity.VerityMod;
import com.verity.entity.BoxEntity;
import com.verity.entity.SmilerEntity;
import com.verity.entity.VerityEntity;
import net.minecraft.network.chat.Component;
import net.minecraft.network.protocol.game.ClientboundSetSubtitleTextPacket;
import net.minecraft.network.protocol.game.ClientboundSetTitleTextPacket;
import net.minecraft.network.protocol.game.ClientboundSetTitlesAnimationPacket;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.sounds.SoundEvent;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;
import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.world.effect.MobEffects;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.entity.player.Inventory;
import net.minecraft.world.entity.EntitySelector;
import net.minecraft.world.entity.EquipmentSlot;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.levelgen.Heightmap;
import net.minecraft.world.phys.Vec3;
import net.minecraft.world.level.entity.EntityTypeTest;

import java.text.Normalizer;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Random;
import java.util.UUID;
import java.util.regex.Pattern;

/**
 * Historia de Verity (port del script de Bedrock): amistad -> algo extraño -> obsesión -> amenaza.
 * Las fases avanzan por días de Minecraft (1 día = 24000 ticks) según el tiempo absoluto del mundo.
 */
public final class StoryManager {
    private StoryManager() {}

    // ================== AJUSTES DE LA HISTORIA ==================
    public static final long DAY_TICKS = 24000L;
    public static final int PHASE1_DAYS = 1;       // amigo
    public static final int PHASE2_DAYS = 1;       // algo extraño
    public static final int THREAT_DAYS = 3;       // fase 3: del aviso nocturno a la llegada del Smiler
    public static final int IGNORE_WARN = 60;      // segundos sin hablarle -> se preocupa
    public static final int IGNORE_STRIKE = 150;   // segundos sin hablarle -> abandono
    public static final int CHASE_SECONDS = 300;   // fase 4: segundos que hay que sobrevivir
    public static final double FAR_SPAWN = 55.0;   // bloques a los que aparece el Smiler
    public static final double HEAR_RANGE = 32.0;

    private static final Random RNG = new Random();
    private static MinecraftServer server;
    private static boolean smilerOn = false;
    private static boolean transforming = false;

    private static class PState {
        int next = 20 + RNG.nextInt(21), quiet = 0, far = 0, lag = 0, farCd = 0, noSmiler = 0, hb = 0, lastEv = -1;
    }

    private static final Map<UUID, PState> STATES = new HashMap<>();

    private static PState st(Player p) {
        return STATES.computeIfAbsent(p.getUUID(), k -> new PState());
    }

    // ================== ACCESO ==================
    public static void setServer(MinecraftServer s) {
        server = s;
        transforming = false;
        smilerOn = false;
        STATES.clear();
        Scheduler.clear();
    }

    public static MinecraftServer server() { return server; }

    private static VerityData data() { return VerityData.get(server); }

    public static int phase() { return data().phase; }

    private static long now() { return server.overworld().getGameTime(); }

    private static boolean isNight() {
        long t = server.overworld().getDayTime() % DAY_TICKS;
        return t >= 13000 && t < 23000;
    }

    private static int rand(int a, int b) { return a + RNG.nextInt(b - a + 1); }

    private static void dirty() { data().setDirty(); }

    public static int idleFaceFor(VerityEntity v, boolean serious) {
        if (smilerOn && phase() != 5) return Faces.NOFACE;
        return Faces.idle(phase(), serious);
    }

    private static List<VerityEntity> allVerity() {
        List<VerityEntity> out = new ArrayList<>();
        for (ServerLevel l : server.getAllLevels()) out.addAll(l.getEntities(EntityTypeTest.forClass(VerityEntity.class), e -> true));
        return out;
    }

    private static List<SmilerEntity> allSmilers() {
        List<SmilerEntity> out = new ArrayList<>();
        for (ServerLevel l : server.getAllLevels()) out.addAll(l.getEntities(EntityTypeTest.forClass(SmilerEntity.class), e -> true));
        return out;
    }

    private static List<SmilerEntity> storySmilers() {
        List<SmilerEntity> out = new ArrayList<>();
        for (SmilerEntity s : allSmilers()) if (s.isStory()) out.add(s);
        return out;
    }

    public static List<VerityEntity> nearbyVerities(Player p) {
        List<VerityEntity> list = p.level().getEntitiesOfClass(VerityEntity.class, p.getBoundingBox().inflate(HEAR_RANGE));
        list.sort(Comparator.comparingDouble(v -> v.distanceToSqr(p)));
        return list;
    }

    private static Vec3 behind(Player p, double dist) {
        Vec3 look = p.getLookAngle();
        double h = Math.max(0.0001, Math.hypot(look.x, look.z));
        return new Vec3(p.getX() - look.x / h * dist, p.getY(), p.getZ() - look.z / h * dist);
    }

    private static void playRaw(ServerLevel l, double x, double y, double z, String id, SoundSource src, float vol, float pitch) {
        SoundEvent ev = SoundEvent.createVariableRangeEvent(new ResourceLocation(id));
        l.playSound(null, x, y, z, ev, src, vol, pitch);
    }

    private static void actionBar(ServerPlayer p, String msg) {
        p.displayClientMessage(Component.literal(msg), true);
    }

    private static void title(ServerPlayer p, String title, String sub) {
        p.connection.send(new ClientboundSetTitlesAnimationPacket(10, 80, 20));
        p.connection.send(new ClientboundSetTitleTextPacket(Component.literal(title)));
        p.connection.send(new ClientboundSetSubtitleTextPacket(Component.literal(sub)));
    }

    // ================== VOZ ==================
    public static void speak(VerityEntity v, String key, boolean serious) {
        String[] lines = Lines.LINES.get(key);
        if (lines == null || lines.length == 0) return;
        speakIdx(v, key, RNG.nextInt(lines.length), serious);
    }

    public static void speakIdx(VerityEntity v, String key, int idx, boolean serious) {
        String[] lines = Lines.LINES.get(key);
        if (lines == null || !v.isAlive() || !(v.level() instanceof ServerLevel level)) return;
        int i = Math.max(0, Math.min(idx, lines.length - 1));
        String text = lines[i];
        int ph = phase();
        v.startTalk(text.length(), ph, serious, key);

        // voz: verity:line.<clave>_<n> (sounds/line/<clave>_<n>.ogg)
        SoundEvent ev = SoundEvent.createVariableRangeEvent(new ResourceLocation(VerityMod.MODID, "line." + key + "_" + (i + 1)));
        level.playSound(null, v.getX(), v.getY(), v.getZ(), ev, SoundSource.NEUTRAL, 1.0f, 1.0f);

        // las frases salen en el chat
        String col = ph >= 5 ? "§8" : ph == 3 ? "§c" : ph == 2 ? "§7" : "§f";
        for (ServerPlayer p : level.players()) {
            if (p.distanceToSqr(v) <= HEAR_RANGE * HEAR_RANGE) {
                p.sendSystemMessage(Component.literal("<Verity> ").withStyle(net.minecraft.ChatFormatting.YELLOW)
                        .append(Component.literal(col + text)));
            }
        }
    }

    public static void speakLater(VerityEntity v, String key, int ticks, boolean serious) {
        Scheduler.later(ticks, () -> { if (v.isAlive()) speak(v, key, serious); });
    }

    private static void speakLaterIdx(VerityEntity v, String key, int ticks, boolean serious, int idx) {
        Scheduler.later(ticks, () -> { if (v.isAlive()) speakIdx(v, key, idx, serious); });
    }

    private static void flashFace(VerityEntity v, int face, int ticks) {
        v.setFace(face);
        Scheduler.later(ticks, () -> { if (v.isAlive() && !v.isTalking()) v.setFace(idleFaceFor(v, false)); });
    }

    // ================== CONVERSACIÓN ==================
    private static final Pattern STOP_RE = Pattern.compile("(no (camines|te muevas|sigas)|quieta|quiet[oa]|quedate|para de|detente|alto|espera|stop)");
    private static final Pattern FOLLOW_RE = Pattern.compile("(camina|caminar|sigueme|ven conmigo|ven aqui|\\bven\\b|rueda|vamos|follow)");
    private static final Pattern SMILER_RE = Pattern.compile("(smiler|sonrisa|monstruo)");
    private static final Pattern REJECT_SOFT = Pattern.compile("(adios|chao|bye|me voy|hasta luego)");
    private static final Pattern REJECT_HARD = Pattern.compile("(\\bvete\\b|andate|dejame|callate|no te quiero|no eres mi amig|te odio|largo|me aburres|ya no quiero)");

    private static final String[] RE_KEYS = {"greet", "how", "who", "thanks", "joke", "love", "bye", "help", "knows"};
    private static final Pattern[] RE_PAT = {
        Pattern.compile("\\b(hola|hey|buenas|hello|hi)\\b"),
        Pattern.compile("(como estas|que tal|how are you)"),
        Pattern.compile("(quien eres|como te llamas|tu nombre)"),
        Pattern.compile("(gracias|thanks)"),
        Pattern.compile("(chiste|broma)"),
        Pattern.compile("(te quiero|eres genial|me caes bien)"),
        Pattern.compile("(adios|chao|bye|hasta luego)"),
        Pattern.compile("(ayuda|help|que puedes hacer)"),
        Pattern.compile("(sabes todo|lo sabes|todo lo sabes|como sabes)"),
    };
    // claves permitidas por fase (la fase 3 no tiene "bye" ni "knows")
    private static final String[] ORDER1 = {"greet", "how", "who", "thanks", "joke", "love", "bye", "help"};
    private static final String[] ORDER2 = {"greet", "how", "who", "thanks", "joke", "love", "bye", "help", "knows"};
    private static final String[] ORDER3 = {"greet", "how", "who", "thanks", "joke", "love", "help"};

    private static String norm(String s) {
        return Normalizer.normalize(s.toLowerCase(), Normalizer.Form.NFD).replaceAll("\\p{M}", "");
    }

    /** Llega desde el menú "Verity" (paquete del cliente). */
    public static void onTalk(ServerPlayer player, String text) {
        st(player).quiet = 0;
        if (phase() == 4) return; // durante la persecución nadie responde
        List<VerityEntity> vs = nearbyVerities(player);
        if (vs.isEmpty()) return;
        String msg = norm(text.trim());
        if (msg.isEmpty()) return;
        VerityEntity v = vs.get(0);
        Scheduler.later(10, () -> respond(player, v, msg));
    }

    private static void respond(ServerPlayer player, VerityEntity v, String msg) {
        if (!v.isAlive()) return;
        int ph = phase();
        boolean serious = ph >= 2;
        if (ph == 5) { speak(v, "sleepy", false); return; }

        if (STOP_RE.matcher(msg).find()) {
            if (ph == 3) { speak(v, "p3_stop", true); return; }
            v.setFollowing(false);
            speak(v, "p" + ph + "_stop", serious);
            return;
        }
        if (FOLLOW_RE.matcher(msg).find()) {
            v.setFollowing(true);
            speak(v, "p" + ph + "_follow", serious);
            return;
        }
        if (ph == 3 && (REJECT_SOFT.matcher(msg).find() || REJECT_HARD.matcher(msg).find())) { addStrike(player); return; }
        if (ph == 2 && REJECT_HARD.matcher(msg).find()) { speak(v, "p2_reject", true); return; }
        if (SMILER_RE.matcher(msg).find()) { speak(v, "p" + ph + "_smiler", serious); return; }

        String[] order = ph == 1 ? ORDER1 : ph == 2 ? ORDER2 : ORDER3;
        for (String k : order) {
            for (int i = 0; i < RE_KEYS.length; i++) {
                if (RE_KEYS[i].equals(k) && RE_PAT[i].matcher(msg).find()) { speak(v, "p" + ph + "_" + k, serious); return; }
            }
        }
        if (msg.contains("verity")) { speak(v, "p" + ph + "_name", serious); return; }
        speak(v, "p" + ph + "_other", serious);
    }

    // ================== OBJETO / CAJA ==================
    /** Clic izquierdo: Verity se convierte en el objeto. */
    public static void pickUp(ServerPlayer player, VerityEntity v) {
        if (phase() >= 4) return;
        ItemStack stack = new ItemStack(VerityMod.VERITY_ITEM.get());
        if (!player.getInventory().add(stack)) player.drop(stack, false);
        if (phase() == 3) speak(v, "p3_carry", true);
        v.discard();
    }

    public static VerityEntity placeVerity(ServerLevel level, Vec3 pos) {
        VerityEntity v = VerityMod.VERITY.get().create(level);
        if (v == null) return null;
        v.moveTo(pos.x, pos.y, pos.z, 0, 0);
        level.addFreshEntity(v);
        v.setFace(idleFaceFor(v, false));
        return v;
    }

    public static BoxEntity spawnBoxAhead(ServerLevel level, Player p, double dist) {
        BoxEntity box = VerityMod.BOX.get().create(level);
        if (box == null) return null;
        Vec3 look = p.getLookAngle();
        double h = Math.max(0.0001, Math.hypot(look.x, look.z));
        double x = p.getX() + look.x / h * dist, z = p.getZ() + look.z / h * dist;
        // mirando al jugador (yaw que apunta de la caja hacia el jugador)
        float yaw = (float) (Math.toDegrees(Math.atan2(-(p.getX() - x), p.getZ() - z)));
        box.moveTo(x, p.getY(), z, yaw, 0);
        level.addFreshEntity(box);
        level.sendParticles(net.minecraft.core.particles.ParticleTypes.EXPLOSION, x, p.getY() + 0.5, z, 1, 0, 0, 0, 0);
        return box;
    }

    public static void onBoxOpened(ServerPlayer p) {
        VerityData d = data();
        d.boxGiven = true;
        if (d.phase == 1 && d.start < 0) d.start = now();
        d.setDirty();
    }

    /** Verity acaba de salir de la caja: cae rebotando y luego saluda. */
    public static void onVerityFromBox(VerityEntity v) {
        v.setFace(Faces.SMILE1);
        v.startFall(() -> {
            v.setFace(idleFaceFor(v, false));
            int ph = phase();
            speakLater(v, ph == 1 ? "intro" : "box_again", 10, ph >= 2);
        });
    }

    public static void onLogin(ServerPlayer p) {
        Scheduler.later(60, () -> {
            if (!p.isAlive() || p.hasDisconnected()) return;
            VerityData d = data();
            if (d.boxGiven || d.phase != 1) return;
            if (!allVerity().isEmpty() || hasBox()) { d.boxGiven = true; d.setDirty(); return; }
            spawnBoxAhead(p.serverLevel(), p, 3.0);
            d.boxGiven = true;
            d.setDirty();
        });
    }

    private static boolean hasBox() {
        for (ServerLevel l : server.getAllLevels()) if (!l.getEntities(EntityTypeTest.forClass(BoxEntity.class), e -> true).isEmpty()) return true;
        return false;
    }

    /** Un objeto de Verity cayó al suelo (la soltaste con Q): vuelve a ser Verity. */
    public static void onItemDropped(net.minecraft.world.entity.item.ItemEntity ie, ServerLevel level) {
        Vec3 pos = ie.position();
        ie.discard();
        placeVerity(level, pos);
        ServerPlayer near = level.getNearestPlayer(pos.x, pos.y, pos.z, 8.0, false) instanceof ServerPlayer sp ? sp : null;
        if (near != null && phase() == 3) addStrike(near);
    }

    private static void releaseHeldItems() {
        for (ServerPlayer p : server.getPlayerList().getPlayers()) {
            Inventory inv = p.getInventory();
            for (int i = 0; i < inv.getContainerSize(); i++) {
                if (inv.getItem(i).is(VerityMod.VERITY_ITEM.get())) {
                    inv.setItem(i, ItemStack.EMPTY);
                    placeVerity(p.serverLevel(), p.position());
                }
            }
        }
    }

    // ================== FASES ==================
    public static void setPhase(int n) {
        n = Math.max(1, Math.min(5, n));
        VerityData d = data();
        d.phase = n;
        d.prog = 0;
        d.strikes = 0;
        d.start = n == 1 ? -1 : now();
        d.threatAt = -1;
        d.warnDay = -1;
        d.setDirty();
        for (PState s : STATES.values()) { s.next = rand(10, 20); s.quiet = 0; s.far = 0; s.lag = 0; }
        List<VerityEntity> vs = allVerity();

        if (n == 1 || n == 5) for (VerityEntity v : vs) v.setFollowing(false);
        for (VerityEntity v : vs) v.setFace(idleFaceFor(v, false));

        if (n == 2) {
            for (ServerPlayer p : server.getPlayerList().getPlayers()) playRaw(p.serverLevel(), p.getX(), p.getY(), p.getZ(), "minecraft:ambient.cave", SoundSource.AMBIENT, 0.7f, 1.0f);
            for (VerityEntity v : vs) flashFace(v, Faces.NOFACE, 12);
        }
        if (n == 3) {
            for (VerityEntity v : vs) v.setFollowing(true);
            if (!vs.isEmpty()) speakLater(vs.get(0), "p3_enter", 30, true);
        }
        if (n == 4) startThreat();
    }

    // ================== FASE 3: ABANDONOS ==================
    public static void addStrike(ServerPlayer p) {
        VerityData d = data();
        d.strikes++;
        int n = d.strikes;
        List<VerityEntity> near = nearbyVerities(p);
        VerityEntity v = !near.isEmpty() ? near.get(0) : (allVerity().isEmpty() ? null : allVerity().get(0));
        if (v != null) {
            flashFace(v, Faces.NOFACE, 20);
            speakLaterIdx(v, "strike", 20, true, Math.min(n - 1, 2));
        }
        p.level().playSound(null, p.blockPosition(), SoundEvents.WARDEN_HEARTBEAT, SoundSource.HOSTILE, 1.0f, 1.0f);
        if (n == 2) p.addEffect(new MobEffectInstance(MobEffects.DARKNESS, 80, 0, false, false));
        if (d.threatAt > 0) d.threatAt -= DAY_TICKS / 2; // cada abandono acerca media jornada la llegada del Smiler
        d.setDirty();
    }

    // ================== FASE 2: COSAS EXTRAÑAS ==================
    private static final int STRANGE_COUNT = 10;

    private static void strangeEvent(ServerPlayer p, VerityEntity v) {
        PState s = st(p);
        int i;
        do { i = RNG.nextInt(STRANGE_COUNT); } while (i == s.lastEv);
        s.lastEv = i;
        switch (i) {
            case 0 -> speak(v, "s_name", true);
            case 1 -> speak(v, "s_where", true);
            case 2 -> speak(v, "s_hand", true);
            case 3 -> speak(v, "s_heart", true);
            case 4 -> speak(v, server.overworld().getDayTime() % DAY_TICKS > 12500 ? "s_night" : "s_day", true);
            case 5 -> speak(v, "s_time", true);
            case 6 -> speak(v, "s_dim", true);
            case 7 -> speak(v, "s_mystery", true);
            case 8 -> { // parpadeo sin cara
                flashFace(v, Faces.NOFACE, 16);
                playRaw(p.serverLevel(), p.getX(), p.getY(), p.getZ(), "minecraft:ambient.cave", SoundSource.AMBIENT, 0.8f, 1.0f);
            }
            default -> { // se acerca sin que lo veas
                if (v.distanceTo(p) > 4) {
                    Vec3 b = behind(p, 2.5);
                    v.teleportTo(b.x, b.y, b.z);
                    p.level().playSound(null, p.blockPosition(), SoundEvents.WARDEN_HEARTBEAT, SoundSource.HOSTILE, 0.4f, 1.0f);
                }
            }
        }
    }

    // ================== FASE 3: AVISO NOCTURNO ==================
    private static void maybeWarn(VerityEntity v) {
        long t = server.overworld().getDayTime() % DAY_TICKS;
        if (!isNight() || t < 14000) return;
        VerityData d = data();
        long day = now() / DAY_TICKS;
        if (d.warnDay == day) return;       // un aviso por noche
        if (RNG.nextDouble() > 0.15) return; // espontáneo, no a hora fija
        d.warnDay = day;
        String key;
        if (d.threatAt < 0) {
            d.threatAt = now() + THREAT_DAYS * DAY_TICKS;
            key = "p3_warn3";
        } else {
            key = (double) (d.threatAt - now()) / DAY_TICKS > 1.5 ? "p3_warn2" : "p3_warn1";
        }
        d.setDirty();
        speak(v, key, true);
    }

    // ================== BUCLE PRINCIPAL (1 vez por segundo) ==================
    public static void storyTick() {
        if (server == null) return;
        smilerOn = !allSmilers().isEmpty();
        VerityData d = data();
        int ph = d.phase;
        if (ph == 4) { threatTick(); return; }
        for (VerityEntity v : allVerity()) {
            if (v.isTalking()) continue;
            int want = idleFaceFor(v, false);
            int cur = v.getFace();
            if (smilerOn) { if (cur != Faces.NOFACE) v.setFace(Faces.NOFACE); continue; }
            if (cur == Faces.NOFACE) { v.setFace(want); continue; }
            if (ph >= 2 && cur != want) v.setFace(want);
        }
        if (ph >= 5) return;

        boolean nearAny = false;
        for (ServerPlayer p : server.getPlayerList().getPlayers()) {
            PState s = st(p);
            List<VerityEntity> vs = nearbyVerities(p);
            s.quiet++;
            if (s.farCd > 0) s.farCd--;

            if (!vs.isEmpty()) {
                nearAny = true;
                VerityEntity v = vs.get(0);
                if (ph == 2 && --s.next <= 0) { s.next = rand(30, 70); strangeEvent(p, v); }
                if (ph == 3) {
                    if (--s.next <= 0) { s.next = rand(35, 65); speak(v, "p3_obsess", true); }
                    if (d.strikes > 0 && ++s.hb % 10 == 0) p.level().playSound(null, p.blockPosition(), SoundEvents.WARDEN_HEARTBEAT, SoundSource.HOSTILE, 0.5f, 1.0f);
                    if (s.quiet == IGNORE_WARN) speak(v, "p3_quiet", true);
                    if (s.quiet >= IGNORE_STRIKE) { s.quiet = 0; addStrike(p); }
                    if (v.distanceTo(p) > 20) {
                        if (++s.lag >= 5) { s.lag = 0; Vec3 b = behind(p, 3); v.teleportTo(b.x, b.y, b.z); }
                    } else s.lag = 0;
                    maybeWarn(v);
                }
                s.far = 0;
            } else if (ph == 3) {
                // el jugador se ha alejado de verdad: ella lo encuentra donde esté
                if (++s.far >= 8 && s.farCd == 0) {
                    s.far = 0;
                    s.farCd = 60;
                    List<VerityEntity> all = allVerity();
                    Vec3 b = behind(p, 3);
                    if (!all.isEmpty()) {
                        VerityEntity v = all.get(0);
                        if (v.level() != p.level()) { // otra dimensión: se crea una nueva junto al jugador
                            v.discard();
                            VerityEntity nv = placeVerity(p.serverLevel(), b);
                            if (nv != null) { nv.setFollowing(true); speakLater(nv, "p3_found", 15, true); }
                        } else {
                            v.teleportTo(b.x, b.y, b.z);
                            speakLater(v, "p3_found", 15, true);
                        }
                    } else {
                        VerityEntity nv = placeVerity(p.serverLevel(), b);
                        if (nv != null) nv.setFollowing(true);
                    }
                    addStrike(p);
                }
            }
        }
        if (nearAny) d.prog++;

        // Paso de fase por días de Minecraft
        if (d.start < 0) {
            if (ph == 1 && !nearAny) return; // fase 1: el reloj arranca al abrir la caja o al encontrarse con Verity
            d.start = now();
            d.setDirty();
            return;
        }
        if (ph == 3) {
            if (d.threatAt > 0 && now() >= d.threatAt) setPhase(4);
            return;
        }
        long need = (ph == 1 ? PHASE1_DAYS : PHASE2_DAYS) * DAY_TICKS;
        if (now() - d.start >= need) setPhase(ph + 1);
        d.setDirty();
    }

    // ================== FASE 4: LA AMENAZA ==================
    private static void startThreat() {
        if (transforming) return;
        List<ServerPlayer> ps = server.getPlayerList().getPlayers();
        if (ps.isEmpty()) return;
        transforming = true;
        releaseHeldItems();
        data().chaseLeft = CHASE_SECONDS;
        data().setDirty();
        ServerPlayer p = ps.get(0);
        List<VerityEntity> near = nearbyVerities(p);
        VerityEntity v = !near.isEmpty() ? near.get(0) : (allVerity().isEmpty() ? null : allVerity().get(0));
        if (v != null) speak(v, "p4_arrive", true);
        for (ServerPlayer q : ps) q.addEffect(new MobEffectInstance(MobEffects.DARKNESS, 100, 0, false, false));

        Scheduler.later(60, () -> { // el Smiler aparece a lo lejos
            spawnSmilerStory(p, FAR_SPAWN);
            for (ServerPlayer q : server.getPlayerList().getPlayers()) actionBar(q, "§4Algo te observa desde lejos.");
        });
        Scheduler.later(110, () -> { // Verity se esfuma
            for (VerityEntity x : allVerity()) {
                if (x.level() instanceof ServerLevel sl) sl.sendParticles(net.minecraft.core.particles.ParticleTypes.EXPLOSION, x.getX(), x.getY(), x.getZ(), 1, 0, 0, 0, 0);
                x.discard();
            }
            transforming = false;
        });
    }

    public static SmilerEntity spawnSmilerStory(ServerPlayer p, double dist) {
        ServerLevel level = p.serverLevel();
        for (int attempt = 0; attempt < 10; attempt++) {
            double ang = RNG.nextDouble() * Math.PI * 2;
            double d = dist - attempt * 3.0; // si no hay chunk cargado, prueba más cerca
            int x = (int) Math.floor(p.getX() + Math.cos(ang) * d);
            int z = (int) Math.floor(p.getZ() + Math.sin(ang) * d);
            if (!level.hasChunk(x >> 4, z >> 4)) continue;
            int y = level.getHeight(Heightmap.Types.MOTION_BLOCKING_NO_LEAVES, x, z);
            SmilerEntity s = VerityMod.SMILER.get().create(level);
            if (s == null) return null;
            s.moveTo(x + 0.5, y, z + 0.5, 0, 0);
            s.startAsStory();
            level.addFreshEntity(s);
            return s;
        }
        return null;
    }

    private static void threatTick() {
        if (transforming) return;
        List<ServerPlayer> ps = server.getPlayerList().getPlayers();
        if (ps.isEmpty()) return;
        for (ServerPlayer p : ps) {
            PState s = st(p);
            boolean has = false;
            for (SmilerEntity sm : storySmilers()) if (sm.level() == p.level()) has = true;
            if (!has) {
                if (++s.noSmiler >= 8) { s.noSmiler = 0; spawnSmilerStory(p, FAR_SPAWN); }
            } else s.noSmiler = 0;
        }
        boolean hunting = false;
        for (SmilerEntity s : storySmilers()) if (s.getSmState() == SmilerEntity.HUNT) hunting = true;
        if (!hunting) return;
        VerityData d = data();
        d.chaseLeft--;
        d.setDirty();
        if (d.chaseLeft <= 0) escapeEnding();
    }

    /** Final A: sobrevivir -> el Smiler se va, la historia se reinicia y una caja aparece cerca. */
    private static void escapeEnding() {
        List<ServerPlayer> ps = new ArrayList<>(server.getPlayerList().getPlayers());
        for (SmilerEntity s : storySmilers()) {
            if (s.level() instanceof ServerLevel sl) sl.sendParticles(net.minecraft.core.particles.ParticleTypes.EXPLOSION, s.getX(), s.getY(), s.getZ(), 1, 0, 0, 0, 0);
            s.discard();
        }
        setPhase(1);
        for (ServerPlayer p : ps) title(p, "§eSobreviviste", "§7...por ahora");
        Scheduler.later(140, () -> {
            if (ps.isEmpty()) return;
            ServerPlayer p = ps.get(0);
            if (!p.isAlive()) return;
            spawnBoxAhead(p.serverLevel(), p, 7.0);
            actionBar(p, "§7Una caja acaba de aparecer cerca de ti.");
        });
    }

    /** Final B: derrotar al Smiler -> Verity vuelve, pequeña y dormida. */
    private static void killEnding(ServerLevel level, Vec3 loc) {
        setPhase(5);
        for (ServerPlayer p : server.getPlayerList().getPlayers()) {
            p.removeEffect(MobEffects.DARKNESS);
            title(p, "§7Silencio", "§8El Smiler cae");
        }
        Scheduler.later(60, () -> {
            VerityEntity v = placeVerity(level, new Vec3(loc.x, loc.y + 0.5, loc.z));
            if (v == null) return;
            v.setFace(Faces.SLEEP);
            speakLater(v, "end_kill", 80, false);
        });
    }

    public static void onSmilerDied(SmilerEntity s) {
        if (phase() == 4 && s.level() instanceof ServerLevel sl) killEnding(sl, s.position());
    }

    /** Verity murió (por algo que no son los jugadores): vuelve más fuerte en la siguiente fase. */
    public static void onVerityDied(VerityEntity v) {
        int ph = phase();
        if (ph >= 4 || !(v.level() instanceof ServerLevel sl)) return;
        ServerPlayer p = sl.getNearestPlayer(v, 64.0) instanceof ServerPlayer sp ? sp : null;
        if (p == null) return;
        Scheduler.later(100, () -> {
            Vec3 b = behind(p, 3);
            VerityEntity nv = placeVerity(p.serverLevel(), b);
            setPhase(ph + 1);
            if (nv != null && ph + 1 < 4) {
                nv.setFollowing(ph + 1 >= 3);
                speakLater(nv, "rev" + ph, 20, true);
            }
        });
    }

    // ================== COMANDOS ==================
    public static String estado() {
        VerityData d = data();
        String[] names = {"", "1 amigo", "2 algo extraño", "3 obsesión", "4 amenaza", "5 final (Verity dormida)"};
        StringBuilder sb = new StringBuilder("Fase " + names[d.phase]);
        if (d.phase <= 2) {
            long left = d.start < 0 ? -1 : (d.phase == 1 ? PHASE1_DAYS : PHASE2_DAYS) * DAY_TICKS - (now() - d.start);
            sb.append(left < 0 ? " | esperando a que se abra la caja" : String.format(" | siguiente fase en %.1f días", left / (double) DAY_TICKS));
        }
        if (d.phase == 3) {
            sb.append(d.threatAt < 0 ? " | aún sin aviso nocturno" : String.format(" | llega el Smiler en %.1f días", (d.threatAt - now()) / (double) DAY_TICKS));
            sb.append(" | abandonos: ").append(d.strikes);
        }
        return sb.toString();
    }

    public static void reset(ServerPlayer p) {
        for (SmilerEntity s : allSmilers()) s.discard();
        for (VerityEntity v : allVerity()) v.discard();
        for (ServerLevel l : server.getAllLevels()) for (BoxEntity b : l.getEntities(EntityTypeTest.forClass(BoxEntity.class), e -> true)) b.discard();
        transforming = false;
        setPhase(1);
        data().boxGiven = false;
        if (p != null) { spawnBoxAhead(p.serverLevel(), p, 3.0); data().boxGiven = true; }
        data().setDirty();
    }
}
