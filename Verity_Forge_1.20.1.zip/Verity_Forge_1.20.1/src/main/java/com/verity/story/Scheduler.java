package com.verity.story;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

/** Ejecuta tareas dentro de N ticks del servidor (equivale a system.runTimeout de Bedrock). */
public final class Scheduler {
    private static final List<Task> TASKS = new ArrayList<>();
    private static long now = 0;

    private Scheduler() {}

    private static class Task {
        long due;
        Runnable run;
        Task(long due, Runnable run) { this.due = due; this.run = run; }
    }

    public static void later(int ticks, Runnable r) {
        synchronized (TASKS) { TASKS.add(new Task(now + Math.max(1, ticks), r)); }
    }

    public static void tick() {
        now++;
        List<Runnable> due = new ArrayList<>();
        synchronized (TASKS) {
            for (Iterator<Task> it = TASKS.iterator(); it.hasNext();) {
                Task t = it.next();
                if (t.due <= now) { due.add(t.run); it.remove(); }
            }
        }
        for (Runnable r : due) {
            try { r.run(); } catch (RuntimeException e) { e.printStackTrace(); }
        }
    }

    public static void clear() {
        synchronized (TASKS) { TASKS.clear(); }
    }
}
