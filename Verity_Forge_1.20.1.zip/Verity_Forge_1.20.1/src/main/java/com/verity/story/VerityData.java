package com.verity.story;

import net.minecraft.nbt.CompoundTag;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.world.level.saveddata.SavedData;

/** Estado persistente de la historia (se guarda con el mundo). */
public class VerityData extends SavedData {
    public int phase = 1;        // 1 amigo, 2 extraño, 3 obsesión, 4 amenaza, 5 final
    public int prog = 0;
    public int strikes = 0;
    public long start = -1;      // -1: la fase 1 espera a que se abra la caja
    public long threatAt = -1;   // -1: aún no hubo aviso nocturno
    public long warnDay = -1;
    public int chaseLeft = 300;
    public boolean boxGiven = false;

    public static VerityData get(MinecraftServer server) {
        ServerLevel overworld = server.overworld();
        return overworld.getDataStorage().computeIfAbsent(VerityData::load, VerityData::new, "verity_story");
    }

    public static VerityData load(CompoundTag t) {
        VerityData d = new VerityData();
        d.phase = t.getInt("phase");
        if (d.phase < 1) d.phase = 1;
        d.prog = t.getInt("prog");
        d.strikes = t.getInt("strikes");
        d.start = t.getLong("start");
        d.threatAt = t.getLong("threatAt");
        d.warnDay = t.getLong("warnDay");
        d.chaseLeft = t.getInt("chaseLeft");
        d.boxGiven = t.getBoolean("boxGiven");
        return d;
    }

    @Override
    public CompoundTag save(CompoundTag t) {
        t.putInt("phase", phase);
        t.putInt("prog", prog);
        t.putInt("strikes", strikes);
        t.putLong("start", start);
        t.putLong("threatAt", threatAt);
        t.putLong("warnDay", warnDay);
        t.putInt("chaseLeft", chaseLeft);
        t.putBoolean("boxGiven", boxGiven);
        return t;
    }
}
