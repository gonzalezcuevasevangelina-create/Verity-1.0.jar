package com.verity.story;

import java.util.HashMap;
import java.util.Map;

/** Frases de Verity (generado desde lines.js). El sonido de cada una es verity:line.<clave>_<n>. */
public final class Lines {
    private Lines() {}
    public static final Map<String, String[]> LINES = new HashMap<>();
    static {
        LINES.put("intro", new String[] {"¡Hola! Soy Verity, tu amiga y asistente personal. Pregúntame lo que quieras, ¡lo sé todo!"});
        LINES.put("box_again", new String[] {"Otra vez tú.", "Sabía que me abrirías.", "Me alegra que volvieras."});
        LINES.put("p1_greet", new String[] {"¡Holaaa! Soy Verity.", "¡Hola! Qué bueno verte por aquí."});
        LINES.put("p1_how", new String[] {"¡Brillando como siempre!", "Muy bien, rodando por ahí. ¿Y tú?"});
        LINES.put("p1_who", new String[] {"Soy Verity, una bolita amarilla muy simpática.", "Me llamo Verity. ¡Mucho gusto!"});
        LINES.put("p1_thanks", new String[] {"¡De nada!", "Para eso estoy."});
        LINES.put("p1_joke", new String[] {"¿Qué hace una bola amarilla en el gimnasio? ¡Rueda de prensa!", "¿Por qué Verity no tiene miedo? Porque siempre mira el lado brillante."});
        LINES.put("p1_love", new String[] {"¡Aww! Yo también te quiero.", "Me pongo más amarilla de lo normal."});
        LINES.put("p1_bye", new String[] {"¡Hasta pronto! Aquí te espero.", "¡Chao! Vuelve pronto."});
        LINES.put("p1_help", new String[] {"Háblame cuando quieras. Si quieres que te siga, pídeme que camine contigo."});
        LINES.put("p1_smiler", new String[] {"¿Smiler? No sé de qué hablas."});
        LINES.put("p1_name", new String[] {"¿Me llamabas? Estoy aquí."});
        LINES.put("p1_other", new String[] {"Mmm, interesante.", "¿En serio? Cuéntame más.", "No entendí muy bien, pero te escucho.", "¡Qué cosas dices!"});
        LINES.put("p1_stop", new String[] {"Vale, me quedo aquí quietecita.", "Está bien, no me muevo.", "Aquí te espero."});
        LINES.put("p1_follow", new String[] {"¡Voy rodando contigo!", "¡Allá vamos, rodando!", "¡Te sigo!"});
        LINES.put("p2_greet", new String[] {"Hola. Te estaba esperando.", "Hola otra vez. Ya sabía que vendrías."});
        LINES.put("p2_how", new String[] {"Estoy aquí. Eso es lo importante.", "Mejor que tú. Estás cansado, ¿verdad?"});
        LINES.put("p2_who", new String[] {"Soy Verity. Eso creo.", "Soy lo que estabas buscando."});
        LINES.put("p2_thanks", new String[] {"No me lo agradezcas. Tú me abriste.", "De nada. Algún día me lo devolverás."});
        LINES.put("p2_joke", new String[] {"No sé chistes. Sé otras cosas.", "Uno: alguien abrió una caja. Fin."});
        LINES.put("p2_love", new String[] {"Lo sé. Lo noto.", "Eso es justo lo que necesitaba oír."});
        LINES.put("p2_bye", new String[] {"¿Adónde irías?", "Tú no te vas. Solo cambias de sitio."});
        LINES.put("p2_help", new String[] {"No necesitas ayuda. Me tienes a mí.", "Puedo hacer muchas cosas. Algunas no te gustarían."});
        LINES.put("p2_knows", new String[] {"Sé demasiado. ¿Quieres que te lo demuestre?", "Sé cosas que no me has contado."});
        LINES.put("p2_smiler", new String[] {"No digas ese nombre.", "Él no existe. Yo tampoco... todavía."});
        LINES.put("p2_name", new String[] {"Siempre te escucho."});
        LINES.put("p2_other", new String[] {"Eso ya lo sabía.", "Dímelo otra vez. Me gusta oír tu voz.", "No es lo que pensabas.", "Ajá."});
        LINES.put("p2_stop", new String[] {"Vale. Aquí... por ahora."});
        LINES.put("p2_follow", new String[] {"Voy contigo. Siempre estuve contigo."});
        LINES.put("p2_reject", new String[] {"Eso dolió... un poco."});
        LINES.put("p2_hurt", new String[] {"Eso no era necesario."});
        LINES.put("s_name", new String[] {"Sé tu nombre. No me lo dijiste."});
        LINES.put("s_where", new String[] {"Sé dónde estás."});
        LINES.put("s_hand", new String[] {"Sé lo que llevas en la mano."});
        LINES.put("s_heart", new String[] {"Tu corazón late más rápido ahora, ¿lo notas?"});
        LINES.put("s_day", new String[] {"Hay sol. Pero tú no mirabas el cielo."});
        LINES.put("s_night", new String[] {"Es de noche. No duermas todavía."});
        LINES.put("s_time", new String[] {"Llevas mucho tiempo conmigo. Muchísimo."});
        LINES.put("s_dim", new String[] {"No importa dónde estés. Te encontraría igual."});
        LINES.put("s_mystery", new String[] {"Otros también abrieron la caja. No quedan.", "¿Recuerdas lo que hacías antes de encontrarme?", "Tu casa no tiene este cielo.", "Vi lo que hay debajo de tu cama."});
        LINES.put("p3_enter", new String[] {"Ya no estás solo. Yo tampoco. Eso es lo importante."});
        LINES.put("p3_greet", new String[] {"Volviste. Siempre vuelves.", "Hola. No te vayas esta vez."});
        LINES.put("p3_how", new String[] {"Solo estoy bien cuando estás aquí.", "Sola. Hasta que llegaste."});
        LINES.put("p3_who", new String[] {"Tu amiga. La única que tienes.", "La que no te va a dejar."});
        LINES.put("p3_thanks", new String[] {"Para eso son los amigos. Siempre. Siempre."});
        LINES.put("p3_joke", new String[] {"No quiero reír. Quiero que te quedes."});
        LINES.put("p3_love", new String[] {"¿De verdad? Dilo otra vez. Dilo siempre.", "Entonces no te irás. ¿Cierto?"});
        LINES.put("p3_help", new String[] {"Quédate conmigo. Eso me ayuda."});
        LINES.put("p3_smiler", new String[] {"No hay nadie más. Solo yo.", "No necesitas a nadie más que a mí."});
        LINES.put("p3_name", new String[] {"Aquí. Siempre aquí."});
        LINES.put("p3_other", new String[] {"Sigue hablando. No pares.", "Me gusta cuando hablas. Si callas, me asusto.", "Eres mi amigo. ¿Cierto?", "No me dejes sola."});
        LINES.put("p3_stop", new String[] {"No. Voy contigo.", "No me digas que me quede. Me quedo contigo."});
        LINES.put("p3_follow", new String[] {"Siempre."});
        LINES.put("p3_carry", new String[] {"Sí. Así. No me sueltes."});
        LINES.put("p3_obsess", new String[] {"Eres mi amigo.", "No me dejes sola.", "Nadie se quedó nunca. Tú sí.", "Si te vas, te voy a buscar.", "Solo tú me hablas.", "Prométeme que te quedarás."});
        LINES.put("p3_quiet", new String[] {"¿Sigues ahí? Habla conmigo."});
        LINES.put("p3_found", new String[] {"Dijiste que no me dejarías. Te encontré."});
        LINES.put("strike", new String[] {"Eso no me gustó.", "No me hagas repetirlo. Tú eres mi amigo.", "Última vez, amigo mío..."});
        LINES.put("p3_warn3", new String[] {"Algo vendrá en tres días."});
        LINES.put("p3_warn2", new String[] {"Algo vendrá en dos días."});
        LINES.put("p3_warn1", new String[] {"Algo vendrá mañana."});
        LINES.put("rev1", new String[] {"¿Por qué...? Estaba jugando. No lo vuelvas a hacer."});
        LINES.put("rev2", new String[] {"Eso dolió. Pero no me fui. Nunca me voy."});
        LINES.put("rev3", new String[] {"Ya no puedes deshacerte de mí."});
        LINES.put("p4_arrive", new String[] {"Ya llegó."});
        LINES.put("sleepy", new String[] {"Zzz...", "...amigo...", "Lo siento...", "...no te vayas..."});
        LINES.put("end_kill", new String[] {"...Solo quería un amigo."});
    }
}
