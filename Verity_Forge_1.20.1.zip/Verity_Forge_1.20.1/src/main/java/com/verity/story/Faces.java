package com.verity.story;

/** Índices de cara (mismo orden que las texturas verity_*.png del addon de Bedrock). */
public final class Faces {
    private Faces() {}

    public static final String[] NAMES = {
        "smile1", "smile2", "smile3", "smile4", "mediumsmile", "neutral1",
        "serious1", "serious2", "serious3",
        "talking1", "talking2", "talking3", "talking4", "talking5",
        "talkingserious", "talkingserious3",
        "hurt", "noface", "sleep", "sleeptalk"
    };

    public static final int SMILE1 = 0, SMILE2 = 1, SMILE3 = 2, SMILE4 = 3, MEDIUMSMILE = 4, NEUTRAL1 = 5;
    public static final int SERIOUS1 = 6, SERIOUS2 = 7, SERIOUS3 = 8;
    public static final int TALKING1 = 9, TALKING2 = 10, TALKING3 = 11, TALKING4 = 12, TALKING5 = 13;
    public static final int TALKINGSERIOUS = 14, TALKINGSERIOUS3 = 15;
    public static final int HURT = 16, NOFACE = 17, SLEEP = 18, SLEEPTALK = 19;

    /** Cara en reposo según la fase de la historia. */
    public static int idle(int phase, boolean serious) {
        switch (phase) {
            case 5: return SLEEP;
            case 3: return serious ? SERIOUS1 : MEDIUMSMILE;
            case 2: return serious ? SERIOUS1 : NEUTRAL1;
            default: return SMILE1;
        }
    }

    /**
     * Caras al hablar:
     *  - fases 1 y 2: siempre talking2 (talking1 si está aburrida: no entendió o nadie le habla)
     *  - fase 3: talking3/4/5, o las "serias" cuando se enfada
     *  - fase 5: dormida hablando
     */
    public static int[] talkPool(int phase, boolean serious, String key) {
        boolean bored = key.endsWith("_other") || key.endsWith("_quiet");
        if (phase == 5) return new int[] {SLEEPTALK};
        if (phase == 3) return serious ? new int[] {TALKINGSERIOUS, TALKINGSERIOUS3} : new int[] {TALKING3, TALKING4, TALKING5};
        return new int[] {bored ? TALKING1 : TALKING2};
    }
}
