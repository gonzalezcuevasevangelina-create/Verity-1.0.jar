package com.verity.item;

import com.verity.client.ClientHooks;
import com.verity.client.VerityItemRenderer;
import com.verity.story.StoryManager;
import net.minecraft.client.renderer.BlockEntityWithoutLevelRenderer;
import net.minecraft.core.BlockPos;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResult;
import net.minecraft.world.InteractionResultHolder;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.context.UseOnContext;
import net.minecraft.world.level.Level;
import net.minecraft.world.phys.Vec3;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.client.extensions.common.IClientItemExtensions;
import net.minecraftforge.fml.DistExecutor;

import java.util.function.Consumer;

/**
 * Verity como objeto, colocable con clic derecho (como un huevo generador, pero no es un huevo).
 * Agachado + clic derecho abre el menú "Verity" si hay una cerca. Se puede llevar en la mano izquierda.
 */
public class VerityItem extends Item {
    public VerityItem(Properties props) {
        super(props);
    }

    @Override
    public InteractionResult useOn(UseOnContext ctx) {
        Player player = ctx.getPlayer();
        if (player != null && player.isShiftKeyDown()) return InteractionResult.PASS; // lo gestiona use()
        Level level = ctx.getLevel();
        if (level.isClientSide) return InteractionResult.SUCCESS;
        BlockPos p = ctx.getClickedPos().relative(ctx.getClickedFace());
        StoryManager.placeVerity((ServerLevel) level, new Vec3(p.getX() + 0.5, p.getY(), p.getZ() + 0.5));
        if (player == null || !player.getAbilities().instabuild) ctx.getItemInHand().shrink(1);
        return InteractionResult.CONSUME;
    }

    @Override
    public InteractionResultHolder<ItemStack> use(Level level, Player player, InteractionHand hand) {
        ItemStack stack = player.getItemInHand(hand);
        if (player.isShiftKeyDown()) { // agachado: menú
            if (level.isClientSide) DistExecutor.unsafeRunWhenOn(Dist.CLIENT, () -> ClientHooks::openVerityScreen);
            return InteractionResultHolder.sidedSuccess(stack, level.isClientSide);
        }
        if (level.isClientSide) return InteractionResultHolder.success(stack);
        Vec3 look = player.getLookAngle();
        double h = Math.max(0.0001, Math.hypot(look.x, look.z));
        Vec3 pos = new Vec3(player.getX() + look.x / h * 1.5, player.getY() + 0.2, player.getZ() + look.z / h * 1.5);
        StoryManager.placeVerity((ServerLevel) level, pos);
        if (!player.getAbilities().instabuild) stack.shrink(1);
        return InteractionResultHolder.consume(stack);
    }

    @Override
    public void initializeClient(Consumer<IClientItemExtensions> consumer) {
        consumer.accept(new IClientItemExtensions() {
            private BlockEntityWithoutLevelRenderer renderer;

            @Override
            public BlockEntityWithoutLevelRenderer getCustomRenderer() {
                if (renderer == null) renderer = new VerityItemRenderer();
                return renderer;
            }
        });
    }
}
