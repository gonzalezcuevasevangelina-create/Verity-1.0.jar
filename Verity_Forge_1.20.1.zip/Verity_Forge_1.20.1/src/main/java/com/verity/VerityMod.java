package com.verity;

import com.verity.entity.BoxEntity;
import com.verity.entity.SmilerEntity;
import com.verity.entity.VerityEntity;
import com.verity.item.BoxItem;
import com.verity.item.VerityItem;
import com.verity.network.Network;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.MobCategory;
import net.minecraft.world.item.CreativeModeTabs;
import net.minecraft.world.item.Item;
import net.minecraftforge.common.ForgeSpawnEggItem;
import net.minecraftforge.event.BuildCreativeModeTabContentsEvent;
import net.minecraftforge.event.entity.EntityAttributeCreationEvent;
import net.minecraftforge.eventbus.api.IEventBus;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.fml.javafmlmod.FMLJavaModLoadingContext;
import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.RegistryObject;

/** verity je bedrock port - port a Forge 1.20.1 del addon de Bedrock. */
@Mod(VerityMod.MODID)
public class VerityMod {
    public static final String MODID = "verity";

    public static final DeferredRegister<EntityType<?>> ENTITIES = DeferredRegister.create(ForgeRegistries.ENTITY_TYPES, MODID);
    public static final DeferredRegister<Item> ITEMS = DeferredRegister.create(ForgeRegistries.ITEMS, MODID);

    // Verity: bola de 0.5 bloques
    public static final RegistryObject<EntityType<VerityEntity>> VERITY = ENTITIES.register("verity",
            () -> EntityType.Builder.of(VerityEntity::new, MobCategory.CREATURE)
                    .sized(0.5f, 0.5f).clientTrackingRange(10).updateInterval(1).build("verity"));

    // Smiler: 8 bloques de alto (modelo original de 3.19 bloques x2.5)
    public static final RegistryObject<EntityType<SmilerEntity>> SMILER = ENTITIES.register("smiler",
            () -> EntityType.Builder.of(SmilerEntity::new, MobCategory.MONSTER)
                    .sized(2.6f, 8.0f).clientTrackingRange(16).fireImmune().build("smiler"));

    public static final RegistryObject<EntityType<BoxEntity>> BOX = ENTITIES.register("box",
            () -> EntityType.Builder.<BoxEntity>of(BoxEntity::new, MobCategory.MISC)
                    .sized(1.0f, 0.85f).clientTrackingRange(10).updateInterval(1).build("box"));

    public static final RegistryObject<Item> VERITY_ITEM = ITEMS.register("verity_item",
            () -> new VerityItem(new Item.Properties().stacksTo(1)));
    public static final RegistryObject<Item> BOX_ITEM = ITEMS.register("box_item",
            () -> new BoxItem(new Item.Properties().stacksTo(16)));
    public static final RegistryObject<Item> SMILER_EGG = ITEMS.register("smiler_spawn_egg",
            () -> new ForgeSpawnEggItem(SMILER, 0xE8DD1A, 0x101010, new Item.Properties()));

    public VerityMod() {
        IEventBus bus = FMLJavaModLoadingContext.get().getModEventBus();
        ENTITIES.register(bus);
        ITEMS.register(bus);
        bus.addListener(this::attributes);
        bus.addListener(this::creativeTab);
        Network.init();
    }

    private void attributes(EntityAttributeCreationEvent e) {
        e.put(VERITY.get(), VerityEntity.createAttributes().build());
        e.put(SMILER.get(), SmilerEntity.createAttributes().build());
    }

    private void creativeTab(BuildCreativeModeTabContentsEvent e) {
        if (e.getTabKey() == CreativeModeTabs.TOOLS_AND_UTILITIES) {
            e.accept(VERITY_ITEM);
            e.accept(BOX_ITEM);
        }
        if (e.getTabKey() == CreativeModeTabs.SPAWN_EGGS) {
            e.accept(SMILER_EGG);
        }
    }
}
