package com.verity.entity;

import com.verity.story.StoryManager;
import net.minecraft.core.BlockPos;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.network.protocol.Packet;
import net.minecraft.network.protocol.game.ClientGamePacketListener;
import net.minecraft.network.syncher.EntityDataAccessor;
import net.minecraft.network.syncher.EntityDataSerializers;
import net.minecraft.network.syncher.SynchedEntityData;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;
import net.minecraft.util.Mth;
import net.minecraft.world.damagesource.DamageSource;
import net.minecraft.world.entity.EntityDimensions;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.Pose;
import net.minecraft.world.entity.ai.attributes.AttributeSupplier;
import net.minecraft.world.entity.ai.attributes.Attributes;
import net.minecraft.world.entity.ai.goal.FloatGoal;
import net.minecraft.world.entity.ai.goal.MeleeAttackGoal;
import net.minecraft.world.entity.monster.Monster;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.phys.Vec3;
import net.minecraftforge.common.Tags;
import net.minecraftforge.network.NetworkHooks;

/**
 * Smiler (8 bloques). Ciclo de la historia: a lo lejos (quieto, mirándote) -> si lo miras se arrodilla
 * -> a los 3 s te persigue -> si hay una ventana a 1 bloque, la rompe, se agacha y entra.
 */
public class SmilerEntity extends Monster {
    public static final int FAR = 0, KNEEL = 1, HUNT = 2;
    private static final EntityDataAccessor<Integer> STATE = SynchedEntityData.defineId(SmilerEntity.class, EntityDataSerializers.INT);
    private static final EntityDataAccessor<Boolean> CROUCH = SynchedEntityData.defineId(SmilerEntity.class, EntityDataSerializers.BOOLEAN);

    public static final int KNEEL_TICKS = 60;          // 3 s de rodillas antes de perseguir
    public static final int WAIT_UNSEEN_TICKS = 1800;  // si no lo miras en 90 s, persigue igual
    public static final int CROUCH_TICKS = 80;         // tiempo agachado tras romper una ventana

    private int stateTicks = 0;
    private int crouchLeft = 0;
    private boolean story = false;

    // Solo cliente: ponderaciones suaves de la pose (arrodillado / agachado) y la escala visual
    public float wKneel = 0, wCrouch = 0, wKneelO = 0, wCrouchO = 0;
    public float visScale = 2.5f, visScaleO = 2.5f;

    public SmilerEntity(EntityType<? extends SmilerEntity> type, Level level) {
        super(type, level);
        setPersistenceRequired();
        this.xpReward = 50;
    }

    public static AttributeSupplier.Builder createAttributes() {
        return Monster.createMonsterAttributes()
                .add(Attributes.MAX_HEALTH, 60.0)
                .add(Attributes.ATTACK_DAMAGE, 6.0)
                .add(Attributes.MOVEMENT_SPEED, 0.3)
                .add(Attributes.FOLLOW_RANGE, 48.0)
                .add(Attributes.KNOCKBACK_RESISTANCE, 1.0);
    }

    @Override
    protected void registerGoals() {
        goalSelector.addGoal(0, new FloatGoal(this));
        goalSelector.addGoal(2, new MeleeAttackGoal(this, 1.2, true));
    }

    @Override
    protected void defineSynchedData() {
        super.defineSynchedData();
        entityData.define(STATE, HUNT);
        entityData.define(CROUCH, false);
    }

    @Override
    public void addAdditionalSaveData(CompoundTag tag) {
        super.addAdditionalSaveData(tag);
        tag.putInt("SmState", getSmState());
        tag.putBoolean("Story", story);
    }

    @Override
    public void readAdditionalSaveData(CompoundTag tag) {
        super.readAdditionalSaveData(tag);
        if (tag.contains("SmState")) entityData.set(STATE, tag.getInt("SmState"));
        story = tag.getBoolean("Story");
    }

    public int getSmState() { return entityData.get(STATE); }
    public boolean isCrouched() { return entityData.get(CROUCH); }
    public boolean isStory() { return story; }

    /** Aparece "a lo lejos": quieto hasta que lo mires. */
    public void startAsStory() {
        story = true;
        entityData.set(STATE, FAR);
        stateTicks = 0;
    }

    @Override
    public void onSyncedDataUpdated(EntityDataAccessor<?> key) {
        super.onSyncedDataUpdated(key);
        if (CROUCH.equals(key)) refreshDimensions();
    }

    @Override
    public EntityDimensions getDimensions(Pose pose) {
        return isCrouched() ? EntityDimensions.scalable(0.8f, 1.8f) : EntityDimensions.scalable(2.6f, 8.0f);
    }

    @Override
    protected float getStandingEyeHeight(Pose pose, EntityDimensions dims) {
        return dims.height * 0.9f;
    }

    @Override
    public boolean hurt(DamageSource source, float amount) {
        if (source.is(net.minecraft.tags.DamageTypeTags.IS_FIRE) && story) return false;
        if (source == damageSources().inWall()) return false;
        return super.hurt(source, amount);
    }

    @Override
    public void tick() {
        super.tick();
        if (level().isClientSide) {
            clientPose();
            return;
        }
        stateTicks++;
        Player p = level().getNearestPlayer(this, 160.0);
        int st = getSmState();

        if (st == FAR || st == KNEEL) {
            getNavigation().stop();
            setDeltaMovement(0, getDeltaMovement().y, 0);
            setTarget(null);
            if (p != null) getLookControl().setLookAt(p, 60.0f, 60.0f);
        }
        if (st == FAR && p != null) {
            boolean seen = isLookedAtBy(p);
            if (seen || distanceTo(p) < 25.0 || stateTicks > WAIT_UNSEEN_TICKS) {
                entityData.set(STATE, KNEEL);
                stateTicks = 0;
            }
        } else if (st == KNEEL) {
            if (stateTicks >= KNEEL_TICKS) {
                entityData.set(STATE, HUNT);
                stateTicks = 0;
                level().playSound(null, blockPosition(), SoundEvents.RAVAGER_ROAR, SoundSource.HOSTILE, 3.0f, 0.6f);
            }
        } else if (st == HUNT) {
            huntLogic(p);
        }
    }

    private boolean isLookedAtBy(Player p) {
        Vec3 view = p.getViewVector(1.0f).normalize();
        Vec3 to = position().add(0, getBbHeight() * 0.6, 0).subtract(p.getEyePosition()).normalize();
        return view.dot(to) > 0.96 && p.hasLineOfSight(this);
    }

    private void huntLogic(Player p) {
        if (p != null && tickCount % 10 == 0) setTarget(p);

        // si se queda muy lejos, reaparece detrás del jugador
        if (p != null && tickCount % 20 == 0 && distanceTo(p) > 48.0 && !isCrouched()) {
            Vec3 look = p.getLookAngle();
            Vec3 pos = p.position().add(-look.x * 30.0, 0, -look.z * 30.0);
            int y = level().getHeight(net.minecraft.world.level.levelgen.Heightmap.Types.MOTION_BLOCKING_NO_LEAVES, (int) pos.x, (int) pos.z);
            teleportTo(pos.x, y, pos.z);
        }
        if (p != null && tickCount % 20 == 0) {
            level().playSound(null, p.blockPosition(), SoundEvents.WARDEN_HEARTBEAT, SoundSource.HOSTILE, 1.0f, 1.0f);
        }

        // ventana a 1 bloque: la rompe, se agacha y entra
        if (tickCount % 5 == 0 && !isCrouched()) {
            BlockPos win = findWindow();
            if (win != null) {
                breakWindow(win);
                entityData.set(CROUCH, true);
                crouchLeft = CROUCH_TICKS;
            }
        }
        if (isCrouched()) {
            if (--crouchLeft <= 0 && canStand()) {
                entityData.set(CROUCH, false);
                crouchLeft = 0;
            }
        }
    }

    private boolean isGlass(BlockState s) {
        return s.is(Tags.Blocks.GLASS) || s.is(Tags.Blocks.GLASS_PANES);
    }

    /** Busca cristal a ~1 bloque de distancia alrededor del Smiler (alturas 0 a 3). */
    private BlockPos findWindow() {
        BlockPos base = blockPosition();
        int r = Mth.ceil(getBbWidth() / 2.0f) + 1;
        for (int dy = 0; dy <= 3; dy++) {
            for (int dx = -r; dx <= r; dx++) {
                for (int dz = -r; dz <= r; dz++) {
                    if (Math.abs(dx) != r && Math.abs(dz) != r) continue; // solo el borde: "a 1 bloque"
                    BlockPos b = base.offset(dx, dy, dz);
                    if (isGlass(level().getBlockState(b))) return b;
                }
            }
        }
        return null;
    }

    private void breakWindow(BlockPos at) {
        for (int dy = -1; dy <= 2; dy++) {
            BlockPos b = at.above(dy);
            if (isGlass(level().getBlockState(b))) level().destroyBlock(b, false);
        }
        level().playSound(null, at, SoundEvents.GLASS_BREAK, SoundSource.HOSTILE, 2.0f, 0.7f);
    }

    private boolean canStand() {
        return level().noCollision(this, EntityDimensions.scalable(2.6f, 8.0f).makeBoundingBox(position()));
    }

    /** Solo cliente: suaviza la pose y la escala. */
    private void clientPose() {
        wKneelO = wKneel;
        wCrouchO = wCrouch;
        visScaleO = visScale;
        int st = getSmState();
        float tk = st == KNEEL ? 1.0f : 0.0f;
        float tc = isCrouched() ? 1.0f : 0.0f;
        wKneel += Mth.clamp(tk - wKneel, -0.15f, 0.15f);
        wCrouch += Mth.clamp(tc - wCrouch, -0.15f, 0.15f);
        float ts = isCrouched() ? 0.8f : 2.5f;
        visScale += Mth.clamp(ts - visScale, -0.25f, 0.25f);
    }

    @Override
    public void die(DamageSource source) {
        super.die(source);
        if (!level().isClientSide) StoryManager.onSmilerDied(this);
    }

    @Override
    public boolean removeWhenFarAway(double d) { return false; }

    @Override
    public Packet<ClientGamePacketListener> getAddEntityPacket() { return NetworkHooks.getEntitySpawningPacket(this); }
}
