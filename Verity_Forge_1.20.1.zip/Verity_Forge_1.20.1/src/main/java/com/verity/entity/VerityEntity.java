package com.verity.entity;

import com.verity.client.ClientHooks;
import com.verity.story.Faces;
import com.verity.story.StoryManager;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.network.protocol.Packet;
import net.minecraft.network.protocol.game.ClientGamePacketListener;
import net.minecraft.network.syncher.EntityDataAccessor;
import net.minecraft.network.syncher.EntityDataSerializers;
import net.minecraft.network.syncher.SynchedEntityData;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResult;
import net.minecraft.world.damagesource.DamageSource;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.Mob;
import net.minecraft.world.entity.PathfinderMob;
import net.minecraft.world.entity.ai.attributes.AttributeSupplier;
import net.minecraft.world.entity.ai.attributes.Attributes;
import net.minecraft.world.entity.ai.goal.AvoidEntityGoal;
import net.minecraft.world.entity.ai.goal.FloatGoal;
import net.minecraft.world.entity.ai.goal.Goal;
import net.minecraft.world.entity.ai.goal.LookAtPlayerGoal;
import net.minecraft.world.entity.player.Player;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.level.Level;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.fml.DistExecutor;
import net.minecraftforge.network.NetworkHooks;

import java.util.EnumSet;

/** Verity: bola amarilla. Quieta por defecto y siempre te mira; si se lo pides, te sigue rodando. */
public class VerityEntity extends PathfinderMob {
    private static final EntityDataAccessor<Integer> FACE = SynchedEntityData.defineId(VerityEntity.class, EntityDataSerializers.INT);
    private static final EntityDataAccessor<Boolean> FALLING = SynchedEntityData.defineId(VerityEntity.class, EntityDataSerializers.BOOLEAN);
    private static final EntityDataAccessor<Boolean> FOLLOW = SynchedEntityData.defineId(VerityEntity.class, EntityDataSerializers.BOOLEAN);

    /** Ticks de la animación de caída (sale de la caja). Se cuenta en cliente y servidor. */
    public int fallTicks = 0;
    private int talkTicks = 0;
    private int talkNext = 0;
    private int[] talkPool = {Faces.TALKING2};
    private int talkPhase = 1;
    private boolean talkSerious = false;
    private String talkKey = "";
    private Runnable onFallEnd = null;

    public VerityEntity(EntityType<? extends VerityEntity> type, Level level) {
        super(type, level);
    }

    public static AttributeSupplier.Builder createAttributes() {
        return Mob.createMobAttributes()
                .add(Attributes.MAX_HEALTH, 20.0)
                .add(Attributes.MOVEMENT_SPEED, 0.25)
                .add(Attributes.FOLLOW_RANGE, 24.0);
    }

    @Override
    protected void registerGoals() {
        goalSelector.addGoal(0, new FloatGoal(this));
        goalSelector.addGoal(1, new AvoidEntityGoal<>(this, SmilerEntity.class, 12.0f, 1.4, 1.8));
        goalSelector.addGoal(3, new FollowPlayerGoal(this));
        goalSelector.addGoal(4, new LookAtPlayerGoal(this, Player.class, 24.0f, 1.0f));
    }

    @Override
    protected void defineSynchedData() {
        super.defineSynchedData();
        entityData.define(FACE, 0);
        entityData.define(FALLING, false);
        entityData.define(FOLLOW, false);
    }

    @Override
    public void addAdditionalSaveData(CompoundTag tag) {
        super.addAdditionalSaveData(tag);
        tag.putInt("Face", getFace());
        tag.putBoolean("Follow", isFollowing());
    }

    @Override
    public void readAdditionalSaveData(CompoundTag tag) {
        super.readAdditionalSaveData(tag);
        setFace(tag.getInt("Face"));
        setFollowing(tag.getBoolean("Follow"));
    }

    public int getFace() { return entityData.get(FACE); }
    public void setFace(int f) { entityData.set(FACE, Math.max(0, Math.min(Faces.NAMES.length - 1, f))); }
    public boolean isFollowing() { return entityData.get(FOLLOW); }
    public void setFollowing(boolean b) { entityData.set(FOLLOW, b); }
    public boolean isFalling() { return entityData.get(FALLING); }

    /** Empieza la animación de caída con rebotes (4.125 s) y llama a {@code end} al terminar (84 ticks). */
    public void startFall(Runnable end) {
        entityData.set(FALLING, true);
        fallTicks = 0;
        onFallEnd = end;
    }

    /** Anima la boca al hablar. */
    public void startTalk(int length, int phase, boolean serious, String key) {
        talkPhase = phase;
        talkSerious = serious;
        talkKey = key;
        talkPool = Faces.talkPool(phase, serious, key);
        talkTicks = Math.min(56, 16 + length * 2);
        talkNext = 0;
    }

    public boolean isTalking() { return talkTicks > 0; }

    @Override
    public void tick() {
        super.tick();
        if (isFalling()) {
            fallTicks++;
            if (!level().isClientSide) {
                if (fallTicks == 28 || fallTicks == 48 || fallTicks == 64) {
                    float pitch = fallTicks == 28 ? 1.2f : fallTicks == 48 ? 1.0f : 0.8f;
                    level().playSound(null, blockPosition(), SoundEvents.SLIME_SQUISH_SMALL, SoundSource.NEUTRAL, 0.8f, pitch);
                    setFace(random.nextBoolean() ? Faces.SMILE2 : Faces.SMILE3);
                }
                if (fallTicks >= 84) {
                    entityData.set(FALLING, false);
                    Runnable r = onFallEnd;
                    onFallEnd = null;
                    if (r != null) r.run();
                }
            }
        } else {
            fallTicks = 0;
        }
        if (!level().isClientSide && talkTicks > 0) {
            talkTicks--;
            if (talkNext-- <= 0) {
                talkNext = 4;
                setFace(talkPool[random.nextInt(talkPool.length)]);
            }
            if (talkTicks == 0) setFace(StoryManager.idleFaceFor(this, talkSerious));
        }
    }

    @Override
    public boolean hurt(DamageSource source, float amount) {
        if (source.getEntity() instanceof Player) return false; // los jugadores no pueden dañarla
        if (source.is(net.minecraft.tags.DamageTypeTags.IS_FALL)) return false;
        return super.hurt(source, amount);
    }

    @Override
    public boolean causeFallDamage(float dist, float mult, DamageSource src) { return false; }

    /** Clic izquierdo: la agarras (se convierte en el objeto). Agachado + clic izquierdo: menú. */
    @Override
    public boolean skipAttackInteraction(Entity attacker) {
        if (attacker instanceof Player player) {
            if (player.isShiftKeyDown()) {
                if (level().isClientSide) DistExecutor.unsafeRunWhenOn(Dist.CLIENT, () -> ClientHooks::openVerityScreen);
            } else if (!level().isClientSide && player instanceof ServerPlayer sp) {
                StoryManager.pickUp(sp, this);
            }
            return true;
        }
        return super.skipAttackInteraction(attacker);
    }

    /** Clic derecho: abre el menú "Verity". */
    @Override
    protected InteractionResult mobInteract(Player player, InteractionHand hand) {
        if (level().isClientSide) DistExecutor.unsafeRunWhenOn(Dist.CLIENT, () -> ClientHooks::openVerityScreen);
        return InteractionResult.sidedSuccess(level().isClientSide);
    }

    @Override
    public boolean removeWhenFarAway(double d) { return false; }

    @Override
    public Packet<ClientGamePacketListener> getAddEntityPacket() { return NetworkHooks.getEntitySpawningPacket(this); }

    /** Te sigue (rodando) cuando se lo pides. */
    private static class FollowPlayerGoal extends Goal {
        private final VerityEntity v;
        private Player target;

        FollowPlayerGoal(VerityEntity v) {
            this.v = v;
            setFlags(EnumSet.of(Flag.MOVE));
        }

        @Override
        public boolean canUse() {
            if (!v.isFollowing() || v.isFalling()) return false;
            target = v.level().getNearestPlayer(v, 32.0);
            return target != null && v.distanceToSqr(target) > 9.0;
        }

        @Override
        public boolean canContinueToUse() {
            return v.isFollowing() && target != null && target.isAlive() && v.distanceToSqr(target) > 4.0;
        }

        @Override
        public void tick() {
            v.getNavigation().moveTo(target, 1.1);
        }

        @Override
        public void stop() {
            v.getNavigation().stop();
        }
    }
}
