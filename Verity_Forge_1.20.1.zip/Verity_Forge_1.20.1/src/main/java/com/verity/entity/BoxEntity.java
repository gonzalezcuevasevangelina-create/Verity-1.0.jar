package com.verity.entity;

import com.verity.VerityMod;
import com.verity.story.StoryManager;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.network.protocol.Packet;
import net.minecraft.network.protocol.game.ClientGamePacketListener;
import net.minecraft.network.syncher.EntityDataAccessor;
import net.minecraft.network.syncher.EntityDataSerializers;
import net.minecraft.network.syncher.SynchedEntityData;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResult;
import net.minecraft.world.damagesource.DamageSource;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.level.Level;
import net.minecraftforge.network.NetworkHooks;

/**
 * La caja de Verity. Clic derecho o izquierdo: se abre (animación "open" de 2 s: sube 1 bloque,
 * abre las tapas y se encoge). Verity sale a mitad de la animación y cae con rebotes.
 */
public class BoxEntity extends Entity {
    private static final EntityDataAccessor<Integer> OPEN = SynchedEntityData.defineId(BoxEntity.class, EntityDataSerializers.INT);

    public BoxEntity(EntityType<? extends BoxEntity> type, Level level) {
        super(type, level);
    }

    /** -1 = cerrada (flotando); >=0 = ticks desde que se abrió. */
    public int getOpenTicks() { return entityData.get(OPEN); }

    @Override
    protected void defineSynchedData() {
        entityData.define(OPEN, -1);
    }

    @Override
    protected void readAdditionalSaveData(CompoundTag tag) {}

    @Override
    protected void addAdditionalSaveData(CompoundTag tag) {}

    @Override
    public boolean isPickable() { return true; }

    @Override
    public boolean isAttackable() { return true; }

    @Override
    public boolean hurt(DamageSource source, float amount) { return false; }

    @Override
    public boolean skipAttackInteraction(Entity attacker) { // clic izquierdo = abrir
        if (attacker instanceof ServerPlayer sp) open(sp);
        return true;
    }

    @Override
    public InteractionResult interact(Player player, InteractionHand hand) { // clic derecho = abrir
        if (!level().isClientSide && player instanceof ServerPlayer sp) open(sp);
        return InteractionResult.sidedSuccess(level().isClientSide);
    }

    private void open(ServerPlayer player) {
        if (getOpenTicks() >= 0) return;
        entityData.set(OPEN, 0);
        level().playSound(null, blockPosition(), SoundEvents.CHEST_OPEN, SoundSource.NEUTRAL, 1.0f, 0.9f);
        StoryManager.onBoxOpened(player);
    }

    @Override
    public void tick() {
        super.tick();
        if (level().isClientSide) {
            if (getOpenTicks() >= 0) entityData.set(OPEN, getOpenTicks() + 1);
            return;
        }
        int t = getOpenTicks();
        if (t < 0) return;
        t++;
        entityData.set(OPEN, t);
        if (t == 20 && level() instanceof ServerLevel sl) { // las tapas ya están abiertas: sale Verity
            VerityEntity v = VerityMod.VERITY.get().create(sl);
            if (v != null) {
                v.moveTo(getX(), getY() + 1.0, getZ(), getYRot(), 0);
                sl.addFreshEntity(v);
                StoryManager.onVerityFromBox(v);
            }
        }
        if (t >= 40) {
            if (level() instanceof ServerLevel sl) {
                sl.sendParticles(ParticleTypes.EXPLOSION, getX(), getY() + 1.0, getZ(), 1, 0, 0, 0, 0);
                sl.playSound(null, blockPosition(), SoundEvents.ITEM_PICKUP, SoundSource.NEUTRAL, 0.7f, 1.0f);
            }
            discard();
        }
    }

    @Override
    public Packet<ClientGamePacketListener> getAddEntityPacket() { return NetworkHooks.getEntitySpawningPacket(this); }
}
