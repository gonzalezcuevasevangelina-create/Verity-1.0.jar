# verity je bedrock port — Forge 1.20.1

Port a Java (Forge 1.20.1, 47.3.0) del addon de Bedrock. **Código fuente sin compilar ni probar**
(se escribió sin acceso a Forge ni a Minecraft), así que puede haber errores de compilación que haya que corregir.

## Compilar
1. Descarga el MDK de Forge 1.20.1 (https://files.minecraftforge.net) y copia aquí `gradlew`, `gradlew.bat` y la carpeta `gradle/`
   (o usa un Gradle 8.x instalado). Necesitas JDK 17.
2. `./gradlew build`  → el jar queda en `build/libs/`.
3. Pon el jar en `mods/` de un Minecraft 1.20.1 con Forge 47.x.
   Para probar sin instalar: `./gradlew runClient`.

## Qué incluye
- Verity (bola amarilla, 20 caras), Smiler (8 bloques), caja con la animación de apertura.
- Objeto de Verity (clic derecho para colocarla; en mano se ve en 3D con tus valores de display), caja (objeto) y huevo del Smiler.
- Clic izquierdo a Verity: la agarras. Clic derecho (o agachado + clic izquierdo): menú "Verity" (cuadro de texto + frases rápidas).
- Caja: clic izquierdo o derecho la abre; al entrar por primera vez aparece una caja delante de ti.
- Historia en 4 fases por días de Minecraft, finales, voces (118 sonidos) y frases en el chat (`<Verity> ...`).
- Comandos (op): `/verity fase <1-5>`, `/verity estado`, `/verity reset`.

## Diferencias / cosas a ajustar
- Las poses del Smiler (de rodillas / agachado) y los signos de rotación de los huesos son aproximados: si algo sale girado, se cambia en `BedrockGeo.renderBone` y `SmilerRenderer`.
- El objeto en mano siempre usa la cara `smile1` (no cambia con la emoción).
- El menú es una pantalla de Java (texto + botones), no el formulario de Bedrock.
